-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2023 at 12:52 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medbudd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `ad_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `company` varchar(255) NOT NULL,
  `headquarter` text NOT NULL,
  `country` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`ad_id`, `first_name`, `last_name`, `email`, `company`, `headquarter`, `country`, `password`, `date`) VALUES
(1, 'AdminOne', 'Pharma', 'abc@gmail.com', 'Flakso', 'Nashik', 'India', '$2y$10$eClrEmvU2LN.b5pZVtFpOecrPevzQzPXfHJ9.cdz3ETz9JvP1Rpn6', '2023-05-02 11:06:17'),
(2, 'AdminTwo', 'Pharma', 'def@gmail.com', 'Flenmark', 'Nashik', 'India', '$2y$10$d/hiNtEOsmC/At5gcLOU2u.g3bldkTO3qXOr6GhCOO0LCAo7V1py6', '2023-05-02 11:06:52'),
(3, 'Ganesh', 'Gaitonde', 'ganeshgaitonde@gmail.com', 'Whos Pharma.', 'Mumbai', 'India', 'ganeshgaitonde', '2023-04-25 17:04:32'),
(11, 'Aditya', 'Patil', 'aditya@gmail.com', 'Baigan', 'Nashik', 'India', '$2y$10$EDZoycwgVaiY8zswXnLuXuKu6oBupuFSsmgRny6zi5dtNJM4lUh12', '2023-05-02 10:50:23'),
(12, 'Shraddha', 'Kapoor', 'sk@gmail.com', 'Crocin', 'Nashik', 'India', '$2y$10$4GjjeYHSFYM.BQhvsSeeq.Zcp/u1QbxNhneZ/Ka/cgexOEK2HTjdC', '2023-05-02 10:55:44'),
(13, 'Mohit', 'Mishra', 'mohit@gmail.com', 'Baigan', 'Nashik', 'India', '$2y$10$WVPhg4xLv4.SYStAlnRLPOHTJQDiYjcq55a3P4oSxQLlWiKOwqOm2', '2023-05-02 11:05:20'),
(18, 'Ana De', 'Armas', 'anadearmas@gmail.com', 'Kipla', 'Havana', 'Cuba', '$2y$10$DqE23d3FZbiB9H/MkdjoeudD0y9ub6bmFPHvNnThhE9Usjjn6QlC6', '2023-05-02 11:51:14'),
(19, 'Shraddha', 'Shukla', 'ssk@gmail.com', 'Yes Pharma', 'Nashik', 'India', '$2y$10$ROkatJhM8PKGzISJOSt00Om9xh7K9fc/TWaRymUUcVeJ5jwEqi6bu', '2023-05-02 20:16:27');

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

CREATE TABLE `assigned` (
  `mr_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `unit_target` int(11) NOT NULL DEFAULT 0,
  `unit_achieved` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assigned`
--

INSERT INTO `assigned` (`mr_id`, `p_name`, `unit_target`, `unit_achieved`) VALUES
(102, 'Crocin 650 mg', 10, 0),
(102, 'Zecuf Cough Syrup 100ml', 13, 0),
(102, 'Crocin 650 mg', 10, 0),
(102, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 12, 0),
(102, 'Zecuf Cough Syrup 100ml', 13, 0),
(102, 'Zecuf Cough Syrup 100ml', 24, 0),
(101, 'Crocin 650 mg', 20, 0),
(101, 'Zecuf Cough Syrup 100ml', 10, 0),
(101, 'Crocin 650 mg', 10, 0),
(102, 'Crocin 650 mg', 10, 0),
(102, 'Dolo 650 mg', 11, 0),
(102, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 12, 0),
(102, 'Zecuf Cough Syrup 100ml', 13, 0),
(102, 'Crocin 650 mg', 10, 0),
(102, 'Dolo 650 mg', 10, 0),
(102, 'Crocin 650 mg', 10, 0),
(102, 'Crocin 650 mg', 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `assignedcomplete`
--

CREATE TABLE `assignedcomplete` (
  `mr_id` int(20) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `unit` int(10) NOT NULL,
  `totalprice` int(10) NOT NULL,
  `soldto` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assignedcomplete`
--

INSERT INTO `assignedcomplete` (`mr_id`, `pname`, `unit`, `totalprice`, `soldto`, `date`) VALUES
(102, 'WE', 12, 234, 'EDA', '2023-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `medical_reg`
--

CREATE TABLE `medical_reg` (
  `shopid` int(11) NOT NULL,
  `Medical Name` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `GST NO` varchar(50) NOT NULL,
  `GST CERTIFICATE` varchar(50) NOT NULL,
  `Medical License` varchar(50) NOT NULL,
  `D pharma degree` varchar(50) NOT NULL,
  `Experience` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_reg`
--

INSERT INTO `medical_reg` (`shopid`, `Medical Name`, `Address`, `GST NO`, `GST CERTIFICATE`, `Medical License`, `D pharma degree`, `Experience`) VALUES
(1, 'Ganesh Pharmacy', 'indira nagar nashik', '647A243097', '567A243097', '127A243097', '067A243097', 12),
(2, 'bnkhh', '', '', '', '', '', 0),
(3, '', '', '', '', '', '', 0),
(4, '', '', '', '', '', '', 0),
(5, '', '', '', '', '', '', 0),
(6, '', '', '', '', '', '', 0),
(7, 'GP pharma', 'Nashik', 'hanklcbnakj779', 'abkclklah2348093482', 'nnqkjfbkq7124894', '1nfqlknklq4149808', 2001),
(8, 'Maharashtra pharma', 'Pathardi Road', 'cnklankla890r7820', 'ncklnaklcq414097831', 'nafklnkfqhw473180947', 'naklbnfkqjh12749717', 2017),
(9, 'Maruti pharma', 'Ashwin nagar', 'nacjkab789725', 'njkqnakfjhq214890178', 'cjaikhfqhh28345903185', 'ahjfoiahkh4379817801', 2004),
(10, 'MSS', 'Somewhere', '12312331', '132131', '3123', '13123', 321);

-- --------------------------------------------------------

--
-- Table structure for table `mrsignup`
--

CREATE TABLE `mrsignup` (
  `username` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mrsignup`
--

INSERT INTO `mrsignup` (`username`, `Email`, `Password`) VALUES
('mclancjank', '0', 'mmdmd789'),
('anurag_dubey', '0', 'anu3467'),
('anurag_dubey', 'anuragdubey920@gmail.com', 'anu3467'),
('anurag_dubey', 'anuragdubey920@gmail.com', 'anu3467'),
('Ganesh', 'ganeshbhaugaitonde@gmail.com', '445566777');

-- --------------------------------------------------------

--
-- Table structure for table `mr_app_info`
--

CREATE TABLE `mr_app_info` (
  `mr_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `state` text NOT NULL,
  `headquarter` text NOT NULL,
  `pan_no` varchar(20) NOT NULL,
  `region` text NOT NULL,
  `aadhar_number` bigint(20) NOT NULL,
  `id` blob NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mr_app_info`
--

INSERT INTO `mr_app_info` (`mr_id`, `first_name`, `last_name`, `email`, `state`, `headquarter`, `pan_no`, `region`, `aadhar_number`, `id`, `password`, `date`) VALUES
(101, 'Aditya', 'Patil', 'adityap@gmail.com', 'Maharashtra', 'Nashik', 'ABCD1234', 'Nashik', 123456781111, 0x64756d6d792d6161646861722e6a7067, '$2y$10$k83XgppCvfvjuJitAontdey9McxoWAip.rbhRtYaxiL9AIPKb6ice', '2023-05-02 16:23:42'),
(102, 'Anurag', 'Dube', 'anuragd@gmail.com', 'Maharashtra', 'Nashik', 'ABCD5678', 'Malegaon', 987654321110, 0x64756d6d792d6161646861722e6a7067, '$2y$10$DuKT1z/9HqnQfsIX4JG9zeSjzXzSGTXrdYJQWD2zN0vSLNy8XwYw6', '2023-05-02 16:26:14'),
(103, 'Rahul', 'Yadav', 'rahuly@gmail.com', 'Maharashtra', 'Nashik', 'ABCD1011', 'Niphad', 134679976431, 0x64756d6d792d6161646861722e6a7067, '$2y$10$lWYj1fskjA5BaKteijvbMe4gu1fplbRRLkfP37PodGPWcoRQ2UH06', '2023-05-02 16:31:18'),
(104, 'Shiladh', 'Shinde', 'shailadh@gmail.com', 'Maharashtra', 'Nashik', 'ABCD1213', 'Chandwad', 147963258000, 0x64756d6d792d6161646861722e6a7067, '$2y$10$FgVC9rDlERrJd729znp1OOApfDOsaRGV0EM6sDYtut4hQUdU9jaAK', '2023-05-02 16:32:35'),
(105, 'Suresh', 'Bhide', 'sureshb@gmail.com', 'Maharashtra', 'Mumbai', 'DEFG1234', 'Ratnagiri', 11112222, 0x64756d6d792d6161646861722e6a7067, '$2y$10$dO7R0T2FfyGgwMQoD/4cC.BO4tCaNXBu5gKWH0V2F.W2nE6CdIeQ.', '2023-05-02 16:33:30');

-- --------------------------------------------------------

--
-- Table structure for table `mr_data`
--

CREATE TABLE `mr_data` (
  `mr_id` int(11) NOT NULL,
  `m_id` int(11) NOT NULL,
  `mr_name` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `unit_target` int(11) NOT NULL,
  `unit_achieved` int(11) NOT NULL,
  `achieved` double NOT NULL,
  `target` double NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mr_data`
--

INSERT INTO `mr_data` (`mr_id`, `m_id`, `mr_name`, `region`, `unit_target`, `unit_achieved`, `achieved`, `target`, `status`) VALUES
(101, 1, 'Aditya', 'Nashik', 5, 0, 3000, 10000, 'Available'),
(102, 1, 'Anurag', 'Malegaon', 5, 0, 3500, 10000, 'Available'),
(103, 1, 'Rahul', 'Niphad', 5, 0, 3000, 10000, 'Available'),
(104, 1, 'Shailadh', 'Chandwad', 5, 0, 4000, 10000, 'Available'),
(105, 2, 'Suresh', 'Ratnagiri', 5, 0, 9000, 10000, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `orderscomplete`
--

CREATE TABLE `orderscomplete` (
  `mr_id` int(20) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `totalprice` int(10) NOT NULL,
  `unit` int(10) NOT NULL,
  `shopname` varchar(50) NOT NULL,
  `region` varchar(30) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `mrname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderscomplete`
--

INSERT INTO `orderscomplete` (`mr_id`, `pname`, `totalprice`, `unit`, `shopname`, `region`, `date`, `mrname`) VALUES
(102, 'WE', 234, 12, 'dse', 'nashik', '2023-04-19', 'asd'),
(102, 'WE', 234, 12, 'dse', 'nashik', '2023-04-19', 'asd'),
(102, 'WE', 234, 12, 'dse', 'nashik', '2023-04-23', 'asd'),
(104, 'qwe', 123, 12, 'asedwaq', 'malegoan', '2023-04-27', 'sad'),
(105, 'WE', 234, 12, 'dse', 'nashik', '2023-05-06', 'asd'),
(106, 'qwe', 123, 12, 'asedwaq', 'malegoan', '2023-05-06', 'sad'),
(106, 'qwe', 123, 12, 'malegoan', 'malegoan', '2023-04-11', 'qw'),
(106, 'qwe', 123, 12, 'malegoan', 'malegoan', '2023-05-06', 'qw'),
(103, 'qw', 23, 32, 'jh', 'nat now', '2023-05-06', 'qw'),
(102, 'sm', 123, 12, 'something', 'weq', '2023-05-06', 'qw'),
(104, 'ms', 123, 12, 'we', 'wqe', '2023-05-06', 'asd'),
(102, 'abcde', 123, 12, 'something', 'malegoan', '2023-05-06', 'qw'),
(104, 'mnb', 123, 12, 'we', 'wqe', '2023-05-06', 'asd'),
(102, 'Crocin 650 mg', 123, 12, 'something', 'nat now', '2023-05-05', 'qw');

-- --------------------------------------------------------

--
-- Table structure for table `orderstaken`
--

CREATE TABLE `orderstaken` (
  `p_name` varchar(255) NOT NULL,
  `mrp` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `region` varchar(255) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `mr_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderstaken`
--

INSERT INTO `orderstaken` (`p_name`, `mrp`, `quantity`, `region`, `shop_name`, `mr_id`) VALUES
('Crocin 650 mg', 35, 70, 'Malegaon', 'ABC Medical', 102),
('Dolo 650 mg', 25, 62, 'Malegaon', 'ABC Medical', 102),
('Cofsils Naturals Cough Syrup Bottle 100 Ml', 0, 12, 'Malegaon', '', 102),
('Zecuf Cough Syrup 100ml', 0, 13, 'Malegaon', '', 102),
('Cofsils Naturals Cough Syrup Bottle 100 Ml', 0, 12, 'Nashik', 'Ganesh Pharmacy', 101),
('Crocin 650 mg', 0, 20, 'Malegaon', 'Ganesh Pharmacy', 102),
('Dolo 650 mg', 0, 20, 'Malegaon', 'Ganesh Pharmacy', 102),
('Crocin 650 mg', 0, 10, 'Malegaon', 'Ganesh Pharmacy', 102);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `mrp` double NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_name`, `mrp`, `quantity`) VALUES
(1, 'Crocin 650 mg', 35, 100),
(2, 'Dolo 650 mg', 150, 25),
(3, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 69.7, 20),
(4, 'Zecuf Cough Syrup 100ml', 106.25, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`ad_id`),
  ADD UNIQUE KEY `email` (`email`) USING HASH;

--
-- Indexes for table `medical_reg`
--
ALTER TABLE `medical_reg`
  ADD PRIMARY KEY (`shopid`);

--
-- Indexes for table `mr_app_info`
--
ALTER TABLE `mr_app_info`
  ADD PRIMARY KEY (`mr_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `aadhar_number` (`aadhar_number`),
  ADD UNIQUE KEY `pan_no` (`pan_no`);

--
-- Indexes for table `mr_data`
--
ALTER TABLE `mr_data`
  ADD PRIMARY KEY (`mr_id`),
  ADD KEY `m_id` (`m_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `ad_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `medical_reg`
--
ALTER TABLE `medical_reg`
  MODIFY `shopid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `mr_app_info`
--
ALTER TABLE `mr_app_info`
  MODIFY `mr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
