-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2023 at 05:10 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medbudd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `ad_id` int(11) NOT NULL,
  `ad_name` varchar(255) NOT NULL,
  `headquarter` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`ad_id`, `ad_name`, `headquarter`) VALUES
(1, 'Admin1', 'Nashik, India'),
(2, 'Admin2', 'Mumbai, India');

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

CREATE TABLE `assigned` (
  `mr_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `target` int(11) NOT NULL DEFAULT 0,
  `achieved` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assigned`
--

INSERT INTO `assigned` (`mr_id`, `p_name`, `target`, `achieved`) VALUES
(101, 'Crocin 650 mg', 0, 0),
(102, 'Dolo 650 mg', 0, 0),
(103, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 0, 0),
(104, 'Zecuf Cough Syrup 100ml', 0, 0),
(102, 'Crocin 650 mg', 0, 0),
(102, 'Dolo 650 mg', 0, 0),
(102, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 0, 0),
(102, 'Zecuf Cough Syrup 100ml', 0, 0),
(102, 'Crocin 650 mg', 0, 0),
(102, 'Dolo 650 mg', 0, 0),
(102, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 0, 0),
(102, 'Zecuf Cough Syrup 100ml', 0, 0),
(102, 'Crocin 650 mg', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `medical_reg`
--

CREATE TABLE `medical_reg` (
  `medical_id` int(11) NOT NULL,
  `medical_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_reg`
--

INSERT INTO `medical_reg` (`medical_id`, `medical_name`) VALUES
(1, 'XYZ Medicals');

-- --------------------------------------------------------

--
-- Table structure for table `mr_data`
--

CREATE TABLE `mr_data` (
  `mr_id` int(11) NOT NULL,
  `m_id` int(11) NOT NULL,
  `mr_name` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `achieved` double NOT NULL,
  `target` double NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mr_data`
--

INSERT INTO `mr_data` (`mr_id`, `m_id`, `mr_name`, `region`, `achieved`, `target`, `status`) VALUES
(101, 1, 'Aditya', 'Nashik', 3000, 10000, 'Available'),
(102, 1, 'Anurag', 'Malegaon', 3500, 10000, 'Available'),
(103, 1, 'Rahul', 'Niphad', 3000, 10000, 'Available'),
(104, 1, 'Shailadh', 'Chandwad', 4000, 10000, 'Available'),
(105, 2, 'Suresh', 'Ratnagiri', 9000, 10000, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `orderstaken`
--

CREATE TABLE `orderstaken` (
  `p_name` varchar(255) NOT NULL,
  `mrp` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `region` varchar(255) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `mr_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderstaken`
--

INSERT INTO `orderstaken` (`p_name`, `mrp`, `quantity`, `region`, `shop_name`, `mr_id`) VALUES
('Crocin 650 mg', 35, 70, 'Malegaon', 'ABC Medical', 102),
('Dolo 650 mg', 25, 62, 'Malegaon', 'ABC Medical', 102);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `mrp` double NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_name`, `mrp`, `quantity`) VALUES
(1, 'Crocin 650 mg', 35, 100),
(2, 'Dolo 650 mg', 150, 25),
(3, 'Cofsils Naturals Cough Syrup Bottle 100 Ml', 69.7, 20),
(4, 'Zecuf Cough Syrup 100ml', 106.25, 10);

-- --------------------------------------------------------

--
-- Table structure for table `try`
--

CREATE TABLE `try` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`ad_id`);

--
-- Indexes for table `mr_data`
--
ALTER TABLE `mr_data`
  ADD PRIMARY KEY (`mr_id`),
  ADD KEY `m_id` (`m_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mr_data`
--
ALTER TABLE `mr_data`
  ADD CONSTRAINT `mr_data_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `admininfo` (`ad_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
