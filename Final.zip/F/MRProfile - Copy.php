<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MR Profile</title>

    <link rel="stylesheet" href="css/login.css">
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/signUp.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="Images/Logo.png" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bar Graph -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- CSS Link -->
    <link rel="stylesheet" href="./css/mrProfile.css">
    <!-- ICON -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

</head>

<body>

    <div class="site-wrap">
        <div class="site-navbar py-2">
            <div class="search-wrap">
                <div class="container">
                    <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
                    <form action="#" method="post">
                        <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
                    </form>
                </div>
            </div>

            <div class="container">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="logo">
                        <div class="site-logo">
                            <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo"
                                    class="logoimg">
                                MedBudd</a>
                        </div>
                    </div>
                    <div class="main-nav d-none d-lg-block">
                        <nav class="site-navigation text-right text-md-center" role="navigation">
                            <ul class="site-menu js-clone-nav d-none d-lg-block">
                                <li class="active"><a href="index.php">Home</a></li>
                                <!-- <li><a href="shop.php">Store</a></li> -->
                                
                                <li><a href="about.php">About</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="icons">
                        <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span -->
                                <!-- class="icon-search"></span></a> -->
                        <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
                            <!-- <span class="icon-shopping-bag"></span> -->
                            <!-- <span class="number">2</span> -->
                        <!-- </a> -->
                        <div class="dropdown">
                            <button class="dropbtn"><span class="icon-user"></span></button>
                            <div class="dropdown-content">
                                <a href="logIn.php">MR</a>
                                <a href="adminLogin.php">Admin</a>
                            </div>
                        </div>
                        <a href="logIn.php" class="icons-btn d-inline-block bag"></a>
                        <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                                class="icon-menu"></span></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-light py-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-0"><a href="index.php">Home</a> <span class="mx-2 mb-0">/</span> <strong
                            class="text-black">Profile</strong></div>
                </div>
            </div>
        </div>
        <div class="mainDashboard">
            <div class="firstRow">
                <div class="box1 boxes">
                    <div class="text">
                        <h6 style="color: #5679e0;">SALES (MONTHLY)</h6>
                        <h4 class="text-black">&#x20B9;40,000</h4>
                    </div>
                    <div class="nameIcon">
                        <i class="fa fa-calendar-check-o fa-2x text-gray-300"></i>
                    </div>
                </div>
                <div class="box2 boxes">
                    <div class="text">
                        <h6 style="color: #1cc88a;">SALES (ANNUAL)</h6>
                        <h4 class="text-black">&#x20B9;40,000</h4>
                    </div>
                    <div class="nameIcon2">
                        <i class="fa fa-inr fa-2x text-gray-300"></i>
                    </div>
                </div>
                <div class="box3 boxes">
                    <div class="text">
                        <h6 style="color: #36b9cc">TASK</h6>
                        <div class="progBar">
                            <h4>50%</h4>
                            <progress class="pgBar" id="file" value="50" max="100"></progress>
                            <div class="nameIcon3">
                                <i class="fa fa-tasks fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box4 boxes">
                    <div class="text">
                        <h6 style="color: #f6c23e;">PENDING ORDERS</h6>
                        <h4 class="text-black">116</h4>
                    </div>
                    <div class="nameIcon">
                        <i class="fa fa-bullhorn fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>

            <div class="secondRow">
                <div class="monthlyTarget">
                    <div class="addTitle">
                        <h6>PRODUCT SALES</h6>
                    </div>
                    <canvas id="myChart" style="display: block; box-sizing: border-box; height: 274px; width: 549px;"
                        width="491" height="245"></canvas>
                </div>
                <div class="monthlySells">
                    <div class="addTitle">
                        <h6>MONTHLY SALES</h6>
                    </div>
                    <canvas id="myChart1" style="display: block; box-sizing: border-box; height: 274px; width: 549px;"
                        width="491" height="245"></canvas>
                </div>
            </div>

            <div class="thirdRow">
                <div class="rw-3-bx-1">
                    <div class="addTitle">
                        <h6>UPCOMING ORDERS</h6>
                    </div>
                    <div class="card-body">
                        <h4 class="small font-weight-bold">Server Migration <span class="float-right">20%</span></h4>
                        <div class="progress mb-4">
                            <div class="progress-bar bg-danger" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <h4 class="small font-weight-bold">Sales Tracking <span class="float-right">40%</span></h4>
                        <div class="progress mb-4">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: 40%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <h4 class="small font-weight-bold">Customer Database <span class="float-right">60%</span></h4>
                        <div class="progress mb-4">
                            <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <h4 class="small font-weight-bold">Payout Details <span class="float-right">80%</span></h4>
                        <div class="progress mb-4">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <h4 class="small font-weight-bold">Account Setup <span class="float-right">Complete!</span></h4>
                        <div class="progress">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
                <div class="rw-3-bx-2"></div>
            </div>
        </div>
        <footer class="site-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

                        <div class="block-7">
                            <h3 class="footer-heading mb-4">About Us</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius quae reiciendis distinctio
                                voluptates
                                sed dolorum excepturi iure eaque, aut unde.</p>
                        </div>

                    </div>
                    <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
                        <h3 class="footer-heading mb-4">Quick Links</h3>
                        <ul class="list-unstyled">
                            <li><a href="#">Supplements</a></li>
                            <li><a href="#">Vitamins</a></li>
                            <li><a href="#">Diet &amp; Nutrition</a></li>
                            <li><a href="#">Tea &amp; Coffee</a></li>
                        </ul>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="block-5 mb-5">
                            <h3 class="footer-heading mb-4">Contact Info</h3>
                            <ul class="list-unstyled">
                                <li class="address">Bhujbal Knowledge City, Adgaon, Nashik, Maharashtra, India</li>
                                <li class="phone"><a href="tel://919511660897">+91 9511660897</a></li>
                                <li class="email"><a
                                        href="email://rahulbyadav2002@gmail.com">rahulbyadav2002@gmail.com</a></li>
                            </ul>
                        </div>


                    </div>
                </div>
                <div class="row pt-5 mt-5 text-center">
                    <div class="col-md-12">
                        <p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script> All rights reserved | MedBudd
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>

                </div>
            </div>
        </footer>
    </div>
    <!-- JS Link -->
    <script src="./js/mrProfile.js"></script>
</body>

</html>