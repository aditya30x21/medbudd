<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location: adminLogin.php");
    exit;
}

require 'partials/_dbconnect.php';

$admin = $_SESSION['username'];

$sql = "SELECT ad_id FROM admininfo WHERE email = '$admin'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$adminID = $row['ad_id'];
$conn = mysqli_connect('localhost', 'root', '', 'medbudd');
function adminInfo($conn)
{
    global $adminID;
    $sql = "SELECT * from admininfo where ad_id = $adminID";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $admin_name = $row["first_name"] . " " . $row["last_name"];
        $company_name = $row['company'];
        $headquarters = $row["headquarter"];
    } else {
        $admin_name = "No results found.";
        $company_name = "";
        $headquarters = "";
    }
    return array("name" => $admin_name, "company" => $company_name, "headquarters" => $headquarters);
}

function mr_count($conn)
{
    global $adminID;
    $sql = "select count(*) as total from mr_data inner join admininfo on mr_data.m_id = admininfo.ad_id where ad_id = $adminID";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {
            $mr = $row['total'];
            echo "$mr";
        }
    } else {
        return 0;
    }
}


function thismonth($conn, $n)
{
    $pname = array();
    $unit = array();
    $conn = mysqli_connect('localhost', 'root', '', 'medbudd');
    $getinfo = "select pname,SUM(totalprice) from orderscomplete where MONTH(date) = MONTH(now()) and YEAR(date) = YEAR(now()) GROUP BY pname ORDER BY SUM(totalprice) DESC;";
    $query = mysqli_query($conn, $getinfo);
    $count = 0;

    while ($row = mysqli_fetch_array($query)) {

        array_push($pname, $row['pname']);
        array_push($unit, $row['SUM(totalprice)']);

    }
    print_r($pname);

    if ($n == 0) {
        return ($pname);
    } else if ($n == 1) {
        return ($unit);
    }
}
function product_count($conn)
{
    $sql = "SELECT COUNT(DISTINCT p_name) as totalProducts FROM products";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products = $row['totalProducts'];
            echo "$products";
        }
    } else {
        return 0;
    }
}

function sales($conn)
{
    global $adminID;
    $sql = "SELECT SUM(achieved) as total FROM mr_data where m_id = $adminID";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {
            $sales = number_format($row['total']);
            echo "$sales";
        }
    } else {
        return 0;
    }
}

function orders($conn)
{
    $sql = "SELECT count(*) as total from orderstaken";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $order = number_format($row['total']);
            echo "$order";
        }
    } else {
        return 0;
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Profile</title>

    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" type="text/css" href="css/regManProfile.css?v=2">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="Images/Logo.png" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bar Graph -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-..." crossorigin="anonymous" />
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
    </script>

</head>

<body>

    <div class="site-wrap">
        <div class="site-navbar py-2">
            <div class="search-wrap">
                <div class="container">
                    <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
                    <form action="#" method="post">
                        <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
                    </form>
                </div>
            </div>

            <div class="container">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="logo">
                        <div class="site-logo">
                            <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo"
                                    class="logoimg">
                                MedBudd</a>
                        </div>
                    </div>
                    <div class="main-nav d-none d-lg-block">
                        <nav class="site-navigation text-right text-md-center" role="navigation">
                            <ul class="site-menu js-clone-nav d-none d-lg-block">
                                <li class="active"><a href="index.php">Home</a></li>
                                <!-- <li><a href="shop.php">Store</a></li> -->
                                <li><a href="about.php">About</a></li>
                                <li><a href="contact.php">Contact</a></li>

                            </ul>
                        </nav>
                    </div>
                    <div class="icons">
                        <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span -->
                                <!-- class="icon-search"></span></a> -->
                        <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
                            <!-- <span class="icon-shopping-bag"></span> -->
                            <!-- <span class="number">2</span> -->
                        <!-- </a> -->
                        <?php
                        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
                            echo
                                "<div class='dropdown'>
                                    <button class='dropbtn'><span class='icon-user'></span></button>
                                        <div class='dropdown-content'>
                                            <a href='logIn.php'>MR</a>
                                            <a href='adminLogin.php'>Admin</a>
                                        </div>
                                </div>
                                <a href='logIn.php' class='icons-btn d-inline-block bag'></a>
                                <a href='#' class='site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none'><span
                                class='icon-menu'></span></a>";
                        } else {
                            // Changes here
                            echo "<a href = 'mr_logout.php'>Logout</a>";
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-light py-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-0"><a href="index.php">Home</a> <span class="mx-2 mb-0">/</span> <strong
                            class="text-black">Profile</strong></div>
                </div>
            </div>
        </div>
        <div class="mainDashboard">
            <div class="firstRow">
                <div class="magProfile">
                    <div class="avatar">
                        <img src="./Images/person_1.png" alt="Avatar">
                    </div>
                    <div class="magDetails">

                        <?php
                        $admin = adminInfo($conn);
                        $name = $admin["name"];
                        $hq = $admin["headquarters"];
                        $company = $admin['company'];
                        echo "<h5 class='text-black'> $name </h5>";
                        echo "<h6 class='text-black'><i class = 'fas fa-building'> $company</i><h6>";
                        echo "<i class='fas fa-map-marker-alt'> $hq </i>";

                        // echo "<p>Lorem ipsum dolor sit amet ab toh saach bolde bhai consectetur adipisicing elit. Itaque illum
                        // quas rem exercitationem iusto eum, architecto quod nobis tempore ullam commodi laborum
                        // officiis unde! Maiores.</p>"
                        ?>

                    </div>
                </div>
            </div>
            <br>
            <div> <label style="text-width:20px;text-height:20px"><a href="bigdata.php">Sales</a></label></div>
            <div class="secondRow">
                <div class="box1 boxes">
                    <i class='fa fa-id-card sizeInc'></i>
                    <button class="edit" id="edit"><i class="fa fa-ellipsis-v"></i></button>
                    <div class="editOption" id="editOption">
                        <!-- <button>Add <i class="fa fa-plus text-success"></i></button> -->
                        <a href="signUp.php" target="_blank"><button>Add<i
                                    class="fa fa-plus text-success"></i></button></a>
                    </div>
                    <h5 class="text-light label" id="label">MR</h5>
                    <h2 class="text-light mrCount" id="mrCount">
                        <?php
                        echo mr_count($conn);
                        ?>
                    </h2>
                </div>
                <div class="box2 boxes">
                    <i class="fa fa-medkit sizeInc"></i>
                    <button class="edit2" id="edit2"><i class="fa fa-ellipsis-v"></i></button>
                    <div class="editOption2" id="editOption2">
                        <!-- <button>Add <i class="fa fa-plus text-success"></i></button> -->
                        <a href="addProducts.php" target="_blank"><button>Add<i
                                    class="fa fa-plus text-success"></i></button></a>
                    </div>
                    <h5 class="text-light">Total Products</h5>
                    <h2 class="text-light">
                        <?php
                        echo product_count($conn);
                        ?>
                    </h2>
                </div>
                <div class="box3 boxes">
                    <i class="fa fa-cart-plus sizeInc"></i>
                    <h5 class="text-light">Total Orders</h5>
                    <h2 class="text-light">
                        <?php echo orders($conn); ?>
                    </h2>
                </div>
                <div class="box4 boxes">
                    <i class="fa fa-inr sizeInc"></i>
                    <h5 class="text-light">Total Sales</h5>
                    <h2 class="text-light">
                        <?php echo sales($conn); ?>
                    </h2>
                </div>
            </div>

            <?php
            $sql = "SELECT mr_id, mr_name, region, achieved, target, status 
            FROM mr_data 
            INNER JOIN admininfo ON mr_data.m_id = admininfo.ad_id 
            WHERE ad_id = $adminID";
            // $sql = "SELECT mr_id, mr_name, region, achieved, target, status FROM mr_data WHERE m_id = $adminID";
            $result = mysqli_query($conn, $sql);

            // Check if there are any rows returned from the query
            if (mysqli_num_rows($result) > 0) {
                echo "<div class='thirdRow table-container'>";
                echo "<table class='table'>";
                echo "<tr>
                            <th>MR ID</th>
                            <th>Name</th>
                            <th>Region</th>
                            <th>Target Achieved</th>
                            <th>Target Assigned</th>
                            <th>Status</th>
                        </tr>";

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr><td><a href='mr_stats.php?mr_id=" . $row["mr_id"] . "' target = 'blank'>" . $row["mr_id"] . "</a></td><td>" . $row["mr_name"] . "</td> <td>" . $row["region"] . "</td><td>&#x20B9; " . $row["achieved"] . "</td><td>&#x20B9; " . $row["target"] . "</td><td>" . $row["status"] . "</td></tr>";

                }
                echo "</table>";
                echo "</div>";

            } else {
                echo "No results found";
            }


            mysqli_close($conn);

            ?>

            <!-- <div class="fourthRow">
                <div class="monthlyTarget">
                    <canvas id="thisM" style="display: block; box-sizing: border-box; height: 50vh; width: 35vw;"
                        width="491" height="245"></canvas>
                </div>


            </div> -->

            <script>


                var yvalues = <?php print_r(json_encode(thismonth($conn, 1))); ?>;
                var xvalues = <?php print_r(json_encode(thismonth($conn, 0))); ?>;
                var ctx = document.getElementById('thisM').getContext('2d');
                console.log(xvalues);
                var y = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: xvalues,
                        datasets: [{
                            label: 'Sales',
                            data: yvalues,
                            backgroundColor: ['#FF6384']
                        }]
                    },
                    options: {
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    }
                });


            </script>



            <footer class="site-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

                            <div class="block-7">
                                <h3 class="footer-heading mb-4">About Us</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius quae reiciendis
                                    distinctio
                                    voluptates
                                    sed dolorum excepturi iure eaque, aut unde.</p>
                            </div>

                        </div>
                        <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
                            <h3 class="footer-heading mb-4">Quick Links</h3>
                            <ul class="list-unstyled">
                                <li><a href="#">Supplements</a></li>
                                <li><a href="#">Vitamins</a></li>
                                <li><a href="#">Diet &amp; Nutrition</a></li>
                                <li><a href="#">Tea &amp; Coffee</a></li>
                            </ul>
                        </div>

                        <div class="col-md-6 col-lg-3">
                            <div class="block-5 mb-5">
                                <h3 class="footer-heading mb-4">Contact Info</h3>
                                <ul class="list-unstyled">
                                    <li class="address">Bhujbal Knowledge City, Adgaon, Nashik, Maharashtra, India</li>
                                    <li class="phone"><a href="tel://919511660897">+91 9511660897</a></li>
                                    <li class="email"><a
                                            href="email://rahulbyadav2002@gmail.com">rahulbyadav2002@gmail.com</a></li>
                                </ul>
                            </div>


                        </div>
                    </div>
                    <div class="row pt-5 mt-5 text-center">
                        <div class="col-md-12">
                            <p>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;
                                <script>document.write(new Date().getFullYear());</script> All rights reserved | MedBudd
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            </p>
                        </div>

                    </div>
                </div>
            </footer>
        </div>

        <script src="./js/regManProfile.js"></script>
</body>



</html>

<!-- Improve the user Interface and make the box1 edit button overlap without changing the dimenion of parent div -->