<!DOCTYPE html>
<html lang="en">

<head>
  <title>MedBudd App</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="icon" href="Images/Logo.png" type="image/x-icon">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">

</head>

<body>

  <div class="site-wrap">


    <div class="site-navbar py-2">

      <div class="search-wrap">
        <div class="container">
          <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
          <form action="#" method="post">
            <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
          </form>
        </div>
      </div>

      <div class="container">
        <div class="d-flex align-items-center justify-content-between">
          <div class="logo">
            <div class="site-logo">
              <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo" class="logoimg">
                MedBudd</a>
            </div>
          </div>
          <div class="main-nav d-none d-lg-block">
            <nav class="site-navigation text-right text-md-center" role="navigation">
              <ul class="site-menu js-clone-nav d-none d-lg-block">
                <li class="active"><a href="index.php">Home</a></li>
                <!-- <li><a href="shop.php">Store</a></li> -->
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
              </ul>
            </nav>
          </div>
          <div class="icons">
            <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span -->
            <!-- class="icon-search"></span></a> -->
            <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
            <!-- <span class="icon-shopping-bag"></span> -->
            <!-- <span class="number">2</span> -->
            <!-- </a> -->
            <div class="dropdown">
              <button class="dropbtn"><span class="icon-user"></span></button>
              <div class="dropdown-content">
                <a href="logIn.php">MR</a>
                <a href="adminLogin.php">Admin</a>
              </div>
            </div>
            <a href="logIn.php" class="icons-btn d-inline-block bag"></a>
            <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                class="icon-menu"></span></a>
          </div>
        </div>
      </div>
    </div>

    <div class="site-blocks-cover inner-page" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 mx-auto align-self-center">
            <div class=" text-center">
              <h1>About Us</h1>
              <p>At Med-Budd, our mission is to revolutionize the pharmaceutical industry through cutting-edge software
                solutions. We are a dedicated team of professionals passionate about improving the efficiency and
                effectiveness of medical representatives and the management team. With our innovative software, we aim
                to streamline processes and bridge the gap between pharmaceutical companies, medical representatives,
                and chemists.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section bg-light custom-border-bottom" data-aos="fade">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6">
            <div class="block-16">
              <figure>
                <img src="images/bg_1.jpg" alt="Image placeholder" class="img-fluid rounded">
                <a href="https://vimeo.com/channels/staffpicks/93951774" class="play-button popup-vimeo"><span
                    class="icon-play"></span></a>

              </figure>
            </div>
          </div>
          <div class="col-md-1"></div>
          <div class="col-md-5">


            <div class="site-section-heading pt-3 mb-4">
              <h2 class="text-black">How We Started</h2>
            </div>
            <p>We began with the goal of enhancing the efficiency of the pharmaceutical industry through a comprehensive
              software solution for both medical representatives and the management team. Our solution offers key
              features such as reporting, order-taking from chemists, visit planning, sample management, online
              questionnaires, and event management.</p>

          </div>
        </div>
      </div>
    </div>



    <div class="site-section bg-light custom-border-bottom" data-aos="fade">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 order-md-2">
            <div class="block-16">
              <figure>
                <img src="images/hero_1.jpg" alt="Image placeholder" class="img-fluid rounded">
                <a href="https://vimeo.com/channels/staffpicks/93951774" class="play-button popup-vimeo"><span
                    class="icon-play"></span></a>

              </figure>
            </div>
          </div>
          <div class="col-md-5 mr-auto">


            <div class="site-section-heading pt-3 mb-4">
              <h2 class="text-black">We Are Trusted Company</h2>
            </div>
            <p class="text-black"> "To bridge the gap between the company and the medical representatives, as well as
              between the medical representatives and chemists, we have developed an app called Med-Budd. This app
              offers modern features such as photo-to-text conversion, automatic sales updates, live target details,
              quizzes, and team interaction. What makes us trustworthy is the transparency we maintain throughout the
              requirements and results with our clients, ensuring the security of their data.</p>

          </div>
        </div>
      </div>
    </div>

    <div class="site-section site-section-sm site-blocks-1 border-0" data-aos="fade">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="">
            <div class="icon mr-4 align-self-start">
              <span class="icon-truck text-primary"></span>
            </div>
            <div class="text">
              <h2>Free Shipping</h2>
              <p> We provide free shipping on all our bulk orders to chemists and stockists, allowing them to take
                advantage of this service.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="100">
            <div class="icon mr-4 align-self-start">
              <span class="icon-refresh2 text-primary"></span>
            </div>
            <div class="text">
              <h2>Free Returns</h2>
              <p> If a package is broken or crushed by any chance, or if, by mistake, expired medicines are delivered to
                you, we provide hassle-free return and replacement of our products.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="200">
            <div class="icon mr-4 align-self-start">
              <span class="icon-help text-primary"></span>
            </div>
            <div class="text">
              <h2>Customer Support</h2>
              <p>We provide a dedicated support team for both MR (Medical Representative) and management features. They
                are available around the clock to assist you through chat and call services..</p>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="site-section bg-light custom-border-bottom" data-aos="fade">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 site-section-heading text-center pt-4">
            <h2>The Team</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-6 mb-5">

            <div class="block-38 text-center">
              <div class="block-38-img">
                <div class="block-38-header">
                  <img src="images/person_1.png" alt="Image placeholder" class="mb-4">
                  <h3 class="block-38-heading h4">Rahul Yadav</h3>
                  <p class="block-38-subheading">CEO/Co-Founder</p>
                </div>
                <div class="block-38-body">
                  <p>Rahul is the go-to member of the MedBudd team. He is a B.Tech IT graduate with previous experience
                    in the field of design and user appeal.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 mb-5">
            <div class="block-38 text-center">
              <div class="block-38-img">
                <div class="block-38-header">
                  <img src="images/person_2.png" alt="Image placeholder" class="mb-4">
                  <h3 class="block-38-heading h4">Shailadh Shinde</h3>
                  <p class="block-38-subheading">Founding member</p>
                </div>
                <div class="block-38-body">
                  <p>Always ready to lead with a firm nature and energy, Shailadh has completed his B.Tech in
                    Information Technology. He enjoys leading from the front.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 mb-5">
            <div class="block-38 text-center">
              <div class="block-38-img">
                <div class="block-38-header">
                  <img src="images/person_3.png" alt="Image placeholder" class="mb-4">
                  <h3 class="block-38-heading h4">Anurag Dubey</h3>
                  <p class="block-38-subheading">Founding Member</p>
                </div>
                <div class="block-38-body">
                  <p>Dedicated and hardworking, Anurag has completed his B.Tech in Information Technology. He has been a
                    key member behind the idea of the app.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 mb-5">
            <div class="block-38 text-center">
              <div class="block-38-img">
                <div class="block-38-header">
                  <img src="images/person_4.png" alt="Image placeholder" class="mb-4">
                  <h3 class="block-38-heading h4">Aditya Patil</h3>
                  <p class="block-38-subheading">Founding member</p>
                </div>
                <div class="block-38-body">
                  <p>Aditya is the 'Captain Cool' in our MedBudd team. He is a B.Tech IT graduate with well-rounded
                    skills. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

            <div class="block-7">
              <h3 class="footer-heading mb-4">About Us</h3>
              <p> Meddbudd is a software company based in Nashik, Maharashtra. We mainly work in the domains of web
                development and application development. We have earned a trusted name in our field.</p>
            </div>

          </div>
          <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
            <h3 class="footer-heading mb-4">Quick Links</h3>
            <ul class="list-unstyled">
              <li><a href="#">Supplements</a></li>
              <li><a href="#">Vitamins</a></li>
              <li><a href="#">Diet &amp; Nutrition</a></li>
              <li><a href="#">Tea &amp; Coffee</a></li>
            </ul>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Contact Info</h3>
              <ul class="list-unstyled">
                <li class="address">Bhujbal Knowledge City, Adgaon, Nashik, Maharashtra, India</li>
                <li class="phone"><a href="tel://919511660897">+91 9511660897</a></li>
                <li class="email"><a href="email://rahulbyadav2002@gmail.com">rahulbyadav2002@gmail.com</a></li>
              </ul>
            </div>


          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright &copy;
              <script>document.write(new Date().getFullYear());</script> All rights reserved | MedBudd </a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>

        </div>
      </div>
    </footer>
  </div>

  <div class="script">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
  </div>
</body>

</html>