<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  include 'partials/_dbconnect.php';

  $m_name = $_POST["m_name"];
  $address = $_POST["address"];
  $gst_no = $_POST["gst_no"];
  $gst_reg_c = $_POST["gst_reg_c"];
  $medical_license = $_POST["medical_license"];
  $dpharma_certificate = $_POST["dpharma_certificate"];
  $exp = $_POST["exp"];

  // Check whether this username exists.
  $sql = "INSERT INTO `medical_registration` (`medical_name`, `address`, `gst_reg_no`, `gst_certificate`, `medical_license`, `dpharma_certificate`, `date`) VALUES ('$m_name', '$address', '$gst_no', '$gst_reg_c', '$medical_license', '$dpharma_certificate', '$exp')";
  $result = mysqli_query($conn, $sql);

  if ($result) {
    $showAlert = true;
  }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

  <link rel="stylesheet" href="css/login.css">
  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="Images/Logo.png" type="image/x-icon">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <!-- Link for CSS  -->
  <link rel="stylesheet" href="css/addMediShop.css?v=2">
  <!-- Link for JS  -->
  <link rel="stylesheet" href="js/addMediShop.js">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    integrity="sha512-..." crossorigin="anonymous" />
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>

<body>
  <div class="site-navbar py-2">
    <div class="search-wrap">
      <div class="container">
        <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
        <form action="#" method="post">
          <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
        </form>
      </div>
    </div>

    <div class="container">
      <div class="d-flex align-items-center justify-content-between">
        <div class="logo">
          <div class="site-logo">
            <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo" class="logoimg">
              MedBudd</a>
          </div>
        </div>
        <div class="main-nav d-none d-lg-block">
          <nav class="site-navigation text-right text-md-center" role="navigation">
            <ul class="site-menu js-clone-nav d-none d-lg-block">
              <li class="active"><a href="index.php">Home</a></li>
              <!-- <li><a href="shop.php">Store</a></li> -->
              <li><a href="about.php">About</a></li>
              <li><a href="contact.php">Contact</a></li>
            </ul>
          </nav>
        </div>
        <div class="icons">
          <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span class="icon-search"></span></a> -->
          <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
          <!-- <span class="icon-shopping-bag"></span> -->
          <!-- <span class="number">2</span> -->
          <!-- </a> -->
          <div class="dropdown">
            <button class="dropbtn"><span class="icon-user"></span></button>
            <div class="dropdown-content">
              <a href="logIn.php">MR</a>
              <a href="adminLogin.php">Admin</a>
            </div>
          </div>
          <a href="logIn.php" class="icons-btn d-inline-block bag"></a>
          <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
              class="icon-menu"></span></a>
        </div>
      </div>
    </div>
  </div>
  <div class="addShopform">
    <div class="addImg">
      <img src="./Images/carttonDoctor.avif" alt="Sample photo" class="img-fluid">
    </div>
    <div class="shopFrm">
      <form action="addMediShop.php" method="post">
        <div class="form-outline mb-4">
          <label class="form-label text-black" for="m_name">Medical Name<span class="text-danger">*</span></label>
          <input type="text" id="m_name" name="m_name" class="form-control" />
        </div>

        <div class="form-outline mb-4">
          <label class="form-label text-black" for="address">Address<span class="text-danger">*</span></label>
          <input type="text" id="address" name="address" class="form-control" />
        </div>

        <div class="form-outline mb-4">
          <label class="form-label text-black" for="gst_no">GST Registration Number<span
              class="text-danger">*</span></label>
          <input type="text" id="gst_no" name="gst_no" class="form-control" />
        </div>

        <div class="form-outline mb-4">
          <label class="form-label text-black" for="gst_reg_c">Upload GST Registration Certificate<span
              class="text-danger">*</span></label>
          <input type="file" id="gst_reg_c" name="gst_reg_c" class="form-control" />
        </div>

        <div class="form-outline mb-4">
          <label class="form-label text-black" for="medical_license">Upload Medical License<span
              class="text-danger">*</span></label>
          <input type="file" id="medical_license" name="medical_license" class="form-control" />
        </div>

        <div class="form-outline mb-4">
          <label class="form-label text-black" for="dpharma_certificate">Upload D Pharma Certificate<span
              class="text-danger">*</span></label>
          <input type="file" id="dpharma_certificate" name="dpharma_certificate" class="form-control" />
        </div>

        <div class="form-outline mb-4">
          <label class="form-label text-black" for="exp">Business Experience - Start Date<span
              class="text-danger">*</span></label>
          <input type="date" id="exp" name="exp" class="form-control" />
        </div>

        <button type="submit" class="btn btn-primary btn-block mb-4">Register</button>
      </form>
    </div>

  </div>
  <footer class="site-footer">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

          <div class="block-7">
            <h3 class="footer-heading mb-4">About Us</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius quae reiciendis distinctio
              voluptates
              sed dolorum excepturi iure eaque, aut unde.</p>
          </div>

        </div>
        <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
          <h3 class="footer-heading mb-4">Quick Links</h3>
          <ul class="list-unstyled">
            <li><a href="#">Supplements</a></li>
            <li><a href="#">Vitamins</a></li>
            <li><a href="#">Diet &amp; Nutrition</a></li>
            <li><a href="#">Tea &amp; Coffee</a></li>
          </ul>
        </div>

        <div class="col-md-6 col-lg-3">
          <div class="block-5 mb-5">
            <h3 class="footer-heading mb-4">Contact Info</h3>
            <ul class="list-unstyled">
              <li class="address">Bhujbal Knowledge City, Adgaon, Nashik, Maharashtra, India</li>
              <li class="phone"><a href="tel://919511660897">+91 9511660897</a></li>
              <li class="email"><a href="email://rahulbyadav2002@gmail.com">rahulbyadav2002@gmail.com</a>
              </li>
            </ul>
          </div>


        </div>
      </div>
      <div class="row pt-5 mt-5 text-center">
        <div class="col-md-12">
          <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;
            <script>document.write(new Date().getFullYear());</script> All rights reserved | MedBudd
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
        </div>

      </div>
    </div>
  </footer>

</body>

</html>