<?php
$login = false;
$showError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  include 'partials/_dbconnect.php';

  $email = $_POST["email"];
  $password = $_POST["password"];

  $sql = "Select * from admininfo where email = '$email'";
  $result = mysqli_query($conn, $sql);
  $num = mysqli_num_rows($result);
  if ($num == 1) {
    while ($row = mysqli_fetch_assoc($result)) {
      if (password_verify($password, $row['password'])) {
        $login = true;
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $email;
        header("location: RegManagerProfile.php");
      } else {
        $showError = "Invalid Credentials";
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $email;
        header("location: RegManagerProfile.php");
      }
    }
  } else {
    $showError = "Invalid Credentials";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />

  <link rel="stylesheet" href="css/login.css">
  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="Images/Logo.png" type="image/x-icon">

  <title>MedBudd App</title>
</head>

<body>

  <?php
  if ($login) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> You are logged in.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
  }

  if ($showError) {
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> ' . $showError . '
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div> ';
  }
  ?>

  <div class="site-wrap">
    <div class="site-navbar py-2">

      <div class="search-wrap">
        <div class="container">
          <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
          <form action="#" method="post">
            <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
          </form>
        </div>
      </div>

      <div class="container">
        <div class="d-flex align-items-center justify-content-between">
          <div class="logo">
            <div class="site-logo">
              <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo" class="logoimg">
                MedBudd</a>
            </div>
          </div>
          <div class="main-nav d-none d-lg-block">
            <nav class="site-navigation text-right text-md-center" role="navigation">
              <ul class="site-menu js-clone-nav d-none d-lg-block">
                  <li class="active"><a href="index.php">Home</a></li>
                  <!-- <li><a href="shop.php">Store</a></li> -->
                  <li><a href="about.php">About</a></li>
                  <li><a href="contact.php">Contact</a></li>
              </ul>
            </nav>
          </div>
          <div class="icons">
            <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span class="icon-search"></span></a> -->
            <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
              <!-- <span class="icon-shopping-bag"></span> -->
              <!-- <span class="number">2</span> -->
            <!-- </a> -->
            <div class="dropdown">
              <button class="dropbtn"><span class="icon-user"></span></button>
              <div class="dropdown-content">
                <a href="logIn.php">MR</a>
                <a href="adminLogin.php">Admin</a>
              </div>
            </div>
            <a href="logIn.php" class="icons-btn d-inline-block bag"></a>
            <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                class="icon-menu"></span></a>
          </div>
        </div>
      </div>
    </div>

    <div class="frm">
      <form action="adminLogin.php" class="form" method="post">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <div class="form-inner">
          <!-- <h2>LOGIN</h2> -->
          <label class="btn btn-lg toggle2 tg3">LOGIN</label>
          <a href="./adminSignUp.php" class="btn btn-lg toggle2 tg2" id="tg2">SIGN UP</a>
          <div class="content">
          <div class="content">
            <input class="input" type="email" name="email" placeholder="Email" />
            <input class="input" type="password" name="password" placeholder="Password" />
            <button type="submit" class="btn btn-success btn-lg active">LOGIN</button>
            <!-- <a href="./RegManagerProfile.php" class="btn btn-success btn-lg active">LOGIN</a> -->
          </div>
        </div>
      </form>

    </div>
  </div>

  <div class="script">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script src="./js/login.js"></script>
  </div>
</body>

</html>