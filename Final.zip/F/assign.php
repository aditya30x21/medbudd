



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <style>

.table-container {
    overflow-x: auto;
    margin-top: 2%;
    width: 80%;
}
body {
max-width: max-content;
margin: auto;
}
.table {
    box-shadow: 0px 0px 10px #ccc;
    border-radius: 15px;
    border-spacing: 0 5px;
    width: 100%;
}

.table tr td i {
    color: rgb(75, 236, 11);
}
/* Responsive */
@media only screen and (max-width: 768px) {
    .table-container {
        width: 100%;
        overflow-x: scroll;
        -webkit-overflow-scrolling: touch;
    }
    tr{
        font-size: 10px;
    }
}

@media only screen and (max-width: 576px) {
    .table-container {
        overflow-x: scroll;
        -webkit-overflow-scrolling: touch;
        margin-top: 1rem;
    }
}
.table tr td {
    border: none;
    background-color: rgb(245, 245, 245);
}
        #video {
  border: 1px solid black;
  box-shadow: 2px 2px 3px black;
  width: 320px;
  height: 240px;
}

#photo {
  border: 1px solid black;
  box-shadow: 2px 2px 3px black;
  width: 320px;
  height: 240px;
}

#canvas {
  display: none;
}

.camera {
  width: 340px;
  display: inline-block;
}

.output {
  width: 340px;
  display: inline-block;
  vertical-align: top;
}

#startbutton {
  display: block;
  position: relative;
  margin-left: auto;
  margin-right: auto;
  bottom: 32px;
  background-color: rgba(0, 150, 0, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.7);
  box-shadow: 0px 0px 1px 2px rgba(0, 0, 0, 0.2);
  font-size: 14px;
  font-family: "Lucida Grande", "Arial", sans-serif;
  color: rgba(255, 255, 255, 1);
}

.contentarea {
  font-size: 16px;
  font-family: "Lucida Grande", "Arial", sans-serif;
  width: 760px;
}
    </style>
</head>
<body>
   <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<div class="contentarea">
  
  <div class="camera">
    <video id="video">Video stream not available.</video>
    <button id="startbutton">Take photo</button>
  </div>
  <canvas id="canvas"> </canvas>
  <div class="output">
    <img id="photo" alt="The screen capture will appear in this box." name="imageok"/>
    <input type="hidden" id="comeonman" name="imageValue" value=""/>
  </div>
 
</div>



        <input type="submit" name="button1" value="scan" />

</form>
<script>
    (() => {
  // The width and height of the captured photo. We will set the
  // width to the value defined here, but the height will be
  // calculated based on the aspect ratio of the input stream.

  const width = 320; // We will scale the photo width to this
  let height = 0; // This will be computed based on the input stream

  // |streaming| indicates whether or not we're currently streaming
  // video from the camera. Obviously, we start at false.

  let streaming = false;

  // The various HTML elements we need to configure or control. These
  // will be set by the startup() function.

  let video = null;
  let canvas = null;
  let photo = null;
  let startbutton = null;

  function showViewLiveResultButton() {
    if (window.self !== window.top) {
      // Ensure that if our document is in a frame, we get the user
      // to first open it in its own tab or window. Otherwise, it
      // won't be able to request permission for camera access.
      document.querySelector(".contentarea").remove();
      const button = document.createElement("button");
      button.textContent = "View live result of the example code above";
      document.body.append(button);
      button.addEventListener("click", () => window.open(location.href));
      return true;
    }
    return false;
  }

  function startup() {
    if (showViewLiveResultButton()) {
      return;
    }
    video = document.getElementById("video");
    canvas = document.getElementById("canvas");
    photo = document.getElementById("photo");
    startbutton = document.getElementById("startbutton");

    navigator.mediaDevices
      .getUserMedia({ video: true, audio: false })
      .then((stream) => {
        video.srcObject = stream;
        video.play();
      })
      .catch((err) => {
        console.error(`An error occurred: ${err}`);
      });

    video.addEventListener(
      "canplay",
      (ev) => {
        if (!streaming) {
          height = video.videoHeight / (video.videoWidth / width);

          // Firefox currently has a bug where the height can't be read from
          // the video, so we will make assumptions if this happens.

          if (isNaN(height)) {
            height = width / (4 / 3);
          }

          video.setAttribute("width", width);
          video.setAttribute("height", height);
          canvas.setAttribute("width", width);
          canvas.setAttribute("height", height);
          streaming = true;
        }
      },
      false
    );

    startbutton.addEventListener(
      "click",
      (ev) => {
        takepicture();
        ev.preventDefault();
      },
      false
    );

    clearphoto();
  }

  // Fill the photo with an indication that none has been
  // captured.

  function clearphoto() {
    const context = canvas.getContext("2d");
    context.fillStyle = "#AAA";
    context.fillRect(0, 0, canvas.width, canvas.height);

    const data = canvas.toDataURL("image/png");
    photo.setAttribute("src", data);
  }

  // Capture a photo by fetching the current contents of the video
  // and drawing it into a canvas, then converting that to a PNG
  // format data URL. By drawing it on an offscreen canvas and then
  // drawing that to the screen, we can change its size and/or apply
  // other changes before drawing it.

  function takepicture() {
    const context = canvas.getContext("2d");
    if (width && height) {
      canvas.width = width;
      canvas.height = height;
      context.drawImage(video, 0, 0, width, height);

      const data = canvas.toDataURL("image/png");
    
      photo.setAttribute("src", data);
     // saveBase64AsFile(data, "fil1.jpeg");
     //ll();
     document.getElementById("comeonman").value =data;
      } else {
      clearphoto();
    }
    
    
  }

  // Set up our event listener to run the startup process
  // once loading is complete.
  window.addEventListener("load", startup, false);

}
)();


</script>

</body>
</html>

<?php
// Changed
// $conn = mysqli_connect('localhost', 'root', '', 'medbud');
$conn = mysqli_connect('localhost', 'root', '', 'medbudd');
// 
$a=0;
$a=$_POST['imageValue'];

//echo "<img src=$a width='500' height='600'> ";


//--------------------
use Google\Cloud\Vision\VisionClient;

if($a!=0)
button1($a);

function button1($ak) {
  
require "vendor/autoload.php";

    $vision = new VisionClient(['keyFile' => json_decode(file_get_contents("key.json"),true)]);
    $family=fopen("f.jpg",'r');
    $image = $vision->image($family,['TEXT_DETECTION']);
    $result=$vision->annotate($image)->text();
    $store=""; $i=0; $heading=array(array()); $avgdis=0; $count=0; $serial=[];
    $serialno=array(array()); $desc=""; $qty=""; $unit="";
    $description=[]; $unitt=[]; $quantity=[];
    $varchavg=0;
foreach($result as $text)
{    
    if($i==0)
    {
            $i++;
            continue;  

    }
    $store=$text->description();    
    $store = preg_replace('/\d+/u', '', $store);
    $store = preg_replace('/[^\p{L}\p{N}\s]/u', '', $store);
    $store = preg_replace("/\s+/", "", $store);
    $store = strtolower($store);

    if(str_contains($store,"srno") or str_contains($store,"SrNo")){
    $heading[0][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[0][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[0][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }
    else if(str_contains($store,"Description")){
    $heading[1][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[1][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[1][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }
    else if(str_contains($store,"Qty")){
    $heading[2][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[2][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[2][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }
    else if(str_contains($store,"Unit")){
    $heading[3][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[3][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[3][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }

}
$i=0;
foreach($result as $text)
{
    if($i==0)
    {
        $i++;
        continue;

    } 
    $verticex0 = (int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $verticex1 = (int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $verticex2 = (int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    $verticex3 = (int)$text->info()["boundingPoly"]["vertices"]["3"]["x"];
   
    $avgdis=($heading[0][2]+$heading[0][0]+$heading[1][0])/3;
    $store=$text->description();    
    $store = preg_replace('/\d+/u', '', $store);
    $store = preg_replace('/[^\p{L}\p{N}\s]/u', '', $store);
    $store = preg_replace("/\s+/", "", $store);
    $store = strtolower($store);

    if($verticex0<$avgdis and is_numeric($text->description()))
    {
        $serial[$count]=$text->description();
        $serialno[$count][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["y"];
        $serialno[$count][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["y"];
        $serialno[$count][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["y"];
        $count++;
    }
}

$i=0;

for($j=0;$j<$count-1;$j++)
{
    foreach($result as $text)
    {
        if($i==0)
        {
            $i++;
            continue;
    
        }
        $verticex0 = (int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
        $verticex1 = (int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
        $verticex2 = (int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
        $verticex3 = (int)$text->info()["boundingPoly"]["vertices"]["3"]["x"];     
        
        $verticey0 = (int)$text->info()["boundingPoly"]["vertices"]["0"]["y"];
        $verticey1 = (int)$text->info()["boundingPoly"]["vertices"]["1"]["y"];
        $verticey2 = (int)$text->info()["boundingPoly"]["vertices"]["2"]["y"];
        $verticey3 = (int)$text->info()["boundingPoly"]["vertices"]["3"]["y"];     

        if($verticey0<($serialno[$j+1][0]+$serialno[$j][0]+$serialno[$j][2])/3 and $verticey0>($serialno[$j][0]-($serialno[$j][0]/10)) )
        {   
           
            //$varchavg=(($serialno[$j+1][0]+$serialno[$j][0]+$serialno[$j][2])/3);
            $a=$serialno[$j+1][0];
            if($verticex0>=(($heading[0][0]+$heading[0][2]+$heading[1][0])/3) and $verticex0<$heading[2][0])
            {
                $desc=$desc." ".$text->description();
             

            }
            else if($verticex0>=(($heading[1][0]+$heading[1][2]+$heading[2][0])/3) and $verticex0<$heading[3][0])
            {
                $qty=$qty." ".$text->description();
            } 
            else if($verticex0>=(($heading[2][0]+$heading[2][2]+$heading[3][0])/3) and $verticex0<(($heading[3][2]+$heading[3][0])/2))
            {
                $unit=$unit.$text->description();
            }
        }
    }
    $description[$j]=$desc;
    $quantity[$j]=$qty;
    $unitt[$j]=$unit;
    $desc=null; $qty=""; $unit="";
}
$conn = mysqli_connect('localhost', 'root', '', 'medbudd');
        $sql = "SELECT * FROM medical_reg";
        $resulttoi = $conn->query($sql);    
        ?>
    <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <!--<form method='post' action='" . $_SERVER['PHP_SELF']>   -->
      Sold to: <input type="text" name="soldto">
       <?php
         echo "<div class='thirdRow table-container'>";
         
echo "<table class='table'><tr><th>Description</th><th>Quantity</th><th>Unit</th></tr>";

for($j=0;$j<$count-1;$j++)
{
    
echo "<tr>
<td>{$description[$j]}</td>
<td>{$quantity[$j]}</td>
<td>{$unitt[$j]}</td>
</tr> ";
}
echo "</table>";
?>
<input type='hidden' name='input_name' value="<?php echo htmlentities(serialize($description)); ?>" />
<input type='hidden' name='input_name1' value="<?php echo htmlentities(serialize($quantity)); ?>" />
<input type='hidden' name='input_name2' value="<?php echo htmlentities(serialize($unitt)); ?>" />
<input type='hidden' name='input_name3' value="<?php echo $count; ?>" />

<?php

echo "<input type='submit' name='addProducts' value='Add'>";
echo "</div>";   
}


if(isset($_POST['addProducts'])){
  $count=$_POST['input_name3'];
  $conn = mysqli_connect('localhost', 'root', '', 'medbudd');
  $hq=$_POST['HQ'];
  echo $hq;
  $descrio = unserialize($_POST['input_name']);
  $qtyy = unserialize($_POST['input_name1']);
  $unitr = unserialize($_POST['input_name2']);
  for($i=0;$i<$count;$i++)
  {
     $sql="INSERT INTO assignedcomplete(mr_id,p_name,unit,totalprice,soldto) VALUES (102,'$descrio[$i]',0,'$unitr[$i]','$unitr[$i]*$qtyy[$i]','$hq')";
     $result = mysqli_query($conn,$sql);
  }
  
      // Store the mr_id in a session variable
     // session_start();
     // $_SESSION['mr_id'] = mysqli_insert_id($conn);

     // header("Location: ".$_SERVER['PHP_SELF']."?mr_id=".$pageId);
      // header("Location: ".$_SERVER['PHP_SELF']."?page_id=".$pageId);
      //exit;
  }
  
?>

