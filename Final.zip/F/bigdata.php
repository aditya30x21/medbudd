<?php
$conn = mysqli_connect('localhost', 'root', '', 'medbudd');
$pageId = 102;

$sql = "SELECT p_name FROM products";
    $resulttoi = $conn->query($sql);



    if(isset($_POST['selectdate'])) {
    
    $jk=array();
    $notjk=array();
      $a=$_POST['Products'];
      $b=$_POST['date'];
      
  
     $sql="SELECT pname,SUM(totalprice) FROM orderscomplete WHERE date = '$b' AND pname='$a' GROUP BY pname ORDER BY SUM(totalprice) DESC;";
     $queryty = mysqli_query($conn,$sql);
     echo "jjjjjjj";
while ($row = mysqli_fetch_array($queryty)) {
 print_r($row);
 //echo "jjjjjjj";
    array_push($jk,$row['pname']);
    array_push($notjk,$row['SUM(totalprice)']);
      
}

    }


function totalrevenue($conn)
{
  global $pageId;
    $orders = "SELECT * FROM mr_data WHERE mr_id = $pageId";
    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>MR ID</th>
                <th>Product Name</th>
                <th>Achieved</th>
                <th>Target</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr><td>" . $row["mr_id"] . "</a></td><td>" . $row["p_name"] . "</td> <td>" . $row["achieved"] . "</td><td>" . $row["target"] . "</td></tr>";
        }
        echo "</table>";
        echo "</div>";
 
    } else {
        echo "No results found";
    }

    
}

function topperformers($conn,$n)
{
     $mrid=array();
     $totalprice=array();
     $mrname=array();
    
// Push elements to the array

  $getinfo = "SELECT mr_id,mrname, SUM(totalprice) AS total_price FROM orderscomplete GROUP BY mr_id ORDER BY SUM(totalprice) DESC;";
      $query = mysqli_query($conn,$getinfo);

   while ($row = mysqli_fetch_array($query)) {
        array_push($mrid,$row['mr_id']);
        array_push($totalprice,$row['total_price']);
        array_push($mrname,$row['mrname']);
        
    }
    $getinfo = "SELECT mr_id, SUM(totalprice) AS total_price FROM assignedcomplete GROUP BY mr_id ORDER BY SUM(totalprice) DESC;";
      $query = mysqli_query($conn,$getinfo);
      //print_r($totalprice);

   while ($row = mysqli_fetch_array($query)) {
      $mrId=$row['mr_id'];
      for($i=0;$i<count($mrid);$i++)
      {
        if($mrId==$mrid[$i])
        {
          $totalprice[$i]+=$row['total_price'];
        }
      }
}
if($n==1)
{
  return($totalprice);
}
else if($n==2)
{
  return($mrname);
}else if($n==0)
{
 
  echo "<div class='thirdRow table-container' style={{
    display:grid,
    gridTemplateRows:'max-content 1fr',
  }} >";
  echo "<table class='table'>";
  echo "<tr><th>Mr Name</th><th>Mr ID</th><th>Revenue</th></tr>";
  for($i=0;$i<count($mrid);$i++)
  {
      echo "<tr><td>$mrname[$i]</td><td>$mrid[$i]</td><td>$totalprice[$i]</td></tr>";
  } 
  echo "</table>";
  echo "</div>";
}
}



function thismonth($conn,$n)
{
  $pname=array();
  $unit=array();
  $getinfo = "select pname,SUM(totalprice) from orderscomplete where MONTH(date) = MONTH(now()) and YEAR(date) = YEAR(now()) GROUP BY pname ORDER BY SUM(totalprice) DESC;";
  $query = mysqli_query($conn,$getinfo);

while ($row = mysqli_fetch_array($query)) {
 
    array_push($pname,$row['pname']);
    array_push($unit,$row['SUM(totalprice)']);
      
}


if($n==0)
{
  return($pname);
}else if($n==1)
{
  return($unit);
}
}

function lastmonth($conn,$n)
{
  $pname=array();
  $unit=array();
  $getinfo = "SELECT pname,SUM(totalprice) FROM orderscomplete WHERE month(date) = month(NOW() - INTERVAL 1 MONTH) GROUP BY pname ORDER BY SUM(totalprice) DESC;";

  $query = mysqli_query($conn,$getinfo);

while ($row = mysqli_fetch_array($query)) {
 
    array_push($pname,$row['pname']);
    array_push($unit,$row['SUM(totalprice)']);
      
}


if($n==0)
{
  return($pname);
}else if($n==1)
{
  return($unit);
}
}

function last3month($conn,$n)
{
  $pname=array();
  $unit=array();
  $getinfo = "SELECT pname,SUM(totalprice) FROM orderscomplete WHERE date >=DATE_ADD(NOW(), INTERVAL -3 MONTH) GROUP BY pname ORDER BY SUM(totalprice) DESC;";
  
  $query = mysqli_query($conn,$getinfo);

while ($row = mysqli_fetch_array($query)) {
 
    array_push($pname,$row['pname']);
    array_push($unit,$row['SUM(totalprice)']);
      
}


if($n==0)
{
  return($pname);
}else if($n==1)
{
  return($unit);
}
}
function lastyear($conn,$n)
{
  $pname=array();
  $unit=array();
  $getinfo = "SELECT pname,SUM(totalprice) FROM orderscomplete WHERE YEAR(date) = YEAR(now()) - 1  GROUP BY pname ORDER BY SUM(totalprice) DESC;";
  
  $query = mysqli_query($conn,$getinfo);

while ($row = mysqli_fetch_array($query)) {
 
    array_push($pname,$row['pname']);
    array_push($unit,$row['SUM(totalprice)']);
      
}


if($n==0)
{
  return($pname);
}else if($n==1)
{
  return($unit);
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
  <title>Analytics</title>

  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css?v=2">
  <link rel="stylesheet" href="css/regManProfile.css?v=2">
  <link rel="icon" href="Images/Logo.png" type="image/x-icon">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <!-- Link for CSS  -->
  <link rel="stylesheet" href="css/bigdata.css?v=2">
  <!-- Link for JS  -->
  <link rel="stylesheet" href="js/addMediShop.js">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    integrity="sha512-..." crossorigin="anonymous" />
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

</head>
<body>
  
<div class="site-wrap">
<div class="site-navbar py-2">
            <div class="search-wrap">
                <div class="container">
                    <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
                    <form action="#" method="post">
                        <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
                    </form>
                </div>
            </div>

            <div class="container">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="logo">
                        <div class="site-logo">
                            <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo"
                                    class="logoimg">
                                MedBudd</a>
                        </div>
                    </div>
                    <div class="main-nav d-none d-lg-block">
                        <nav class="site-navigation text-right text-md-center" role="navigation">
                            <ul class="site-menu js-clone-nav d-none d-lg-block">
                                <li class="active"><a href="index.php">Home</a></li>
                                <li><a href="about.php">About</a></li>
                                <li><a href="contact.php">Contact</a></li>

                            </ul>
                        </nav>
                    </div>
                    <div class="icons">
                        <a href="#" class="icons-btn d-inline-block js-search-open"><span
                                class="icon-search"></span></a>
                        <a href="cart.php" class="icons-btn d-inline-block bag">
                            <span class="icon-shopping-bag"></span>
                            <span class="number">2</span>
                        </a>
                        <?php
                        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
                            echo
                                "<div class='dropdown'>
                                    <button class='dropbtn'><span class='icon-user'></span></button>
                                        <div class='dropdown-content'>
                                            <a href='logIn.php'>MR</a>
                                            <a href='adminLogin.php'>Admin</a>
                                        </div>
                                </div>
                                <a href='logIn.php' class='icons-btn d-inline-block bag'></a>
                                <a href='#' class='site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none'><span
                                class='icon-menu'></span></a>";
                        } else {
                            // Changes here
                            echo "<a href = 'mr_logout.php'>Logout</a>";
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="mainDashboard">
            <h3 class="text-black">Sales</h3>
                        
            <canvas id="totalrevenue" style="width: 100%; max-width: 600px; min-width: 280px;"></canvas>

<!-- <style>
@media screen and (max-width: 768px) {
  #totalrevenue {
    max-width: 90%;
  }
}
</style> -->

              <script>
              var yValues = <?php echo json_encode(topperformers($conn,1) ); ?>;
              var xValues = <?php echo json_encode(topperformers($conn,2) ); ?>;
              var barColors = [
                "#b91d47",
                "#00aba9",
                "#2b5797",
                "#e8c3b9",
                "#1e7145"
              ];

              new Chart("totalrevenue", {
                type: "doughnut",
                data: {
                  labels: xValues,
                  datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                  }]
                },
                options: {
                  title: {
                    display: true,
                    text: "Total Sales"
                  }
                }
              });
              </script>

<!-- -->
<!-- To performers -->


                <h3 class="text-black"> TOP performers</h3>


                <!-- -->
                <div>
                  <?php echo topperformers($conn,0); ?>
                </div>


<br><br>


<div>
  <select id="month" onchange="showOptions(this)">
    <option id="tm">This month</option>
    <option id="lm">Last Month</option>
    <option id="l3m">Last 3 Months</option>
    <option id="ly">Last Year</option>
  </select>
</div>

<style>
  #month {
    font-size: 18px;
    color: #fff;
    background-color: #1e88e5;
    border: none;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.3);
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  #month:hover {
    background-color: #0d47a1;
  }

  #month:focus {
    outline: none;
    background-color: #0d47a1;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.3), 0px 0px 0px 3px rgba(30, 136, 229, 0.5);
  }

  #month option {
    background-color: #fff;
    color: #333;
  }

  #month option:checked {
    background-color: #1e88e5;
    color: #fff;
  }
</style>



<div>
  <br>
<div id="thism">
<canvas id="thisM" class="barGraph chartjs-render-monitor" width="1144" height="570"></canvas>
</div>
<div id="lastm" style="display:none;">
<canvas id="lastM" class="barGraph chartjs-render-monitor" width="1144" height="570"></canvas>

</div>
<div id="last3m" style="display:none;">
<canvas id="last3M" class="barGraph chartjs-render-monitor" width="1144" height="570"></canvas>

</div>
<div id="lasty" style="display:none;">
<canvas id="lastY" class="barGraph chartjs-render-monitor" width="1144" height="570"></canvas>

</div>
</div>  



<script>
  

 var xvalues=<?php print_r(json_encode(thismonth($conn,0) )); ?>;
 var yvalues=<?php print_r(json_encode(thismonth($conn,1) )); ?>;
  var ctx = document.getElementById('thisM').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: xvalues,
    datasets: [{
      label: 'Sales',
      data: yvalues,
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
    }]
  },
  options: {
    scales: {
      
      yAxes: [{ 
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
</script>

<script>
  
 var xvalues=<?php print_r(json_encode(lastmonth($conn,0) )); ?>;
 var yvalues=<?php print_r(json_encode(lastmonth($conn,1) )); ?>;
var ctx = document.getElementById('lastM').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: xvalues,
    datasets: [{
      label: 'Sales',
      data: yvalues,
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
    }]
  },
  options: {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
</script>
<script>
  var xvalues=<?php print_r(json_encode(last3month($conn,0) )); ?>;
 var yvalues=<?php print_r(json_encode(last3month($conn,1) )); ?>;
var ctx = document.getElementById('last3M').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: xvalues,
    datasets: [{
      label: 'Sales',
      data: yvalues,
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
    }]
  },
  options: {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
</script>
<script>
  var xvalues=<?php print_r(json_encode(lastyear($conn,0) )); ?>;
 var yvalues=<?php print_r(json_encode(lastyear($conn,1) )); ?>;
var ctx = document.getElementById('lastY').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels:xvalues,
    datasets: [{
      label: 'Sales',
      data: yvalues,
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
    }]
  },
  options: {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
</script>

<script>
  function showOptions(s) {
    const a=s[s.selectedIndex].id;
    const b=document.getElementById("thism");
    const c=document.getElementById("lastm");
    const d=document.getElementById("last3m");
    const e=document.getElementById("lasty");
    if(a=="tm")
    {
       b.style.display = "block";
        c.style.display = "none";
        e.style.display = "none";
        d.style.display = "none";
      
    }else if(a=="lm")
    {
        b.style.display = "none";
        c.style.display = "block";
        e.style.display = "none";
        d.style.display = "none";
    }else if(a=="l3m")
    {
      b.style.display = "none";
        c.style.display = "none";
        e.style.display = "none";
        d.style.display = "block";
    }else if(a=="ly")
    {
      b.style.display = "none";
        c.style.display = "none";
        e.style.display = "block";
        d.style.display = "none";
    }
    };
  
  </script>

  <div>
    <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <select id="Products" name="Products">
    <?php 
  if ($resulttoi->num_rows > 0) {
                while ($optionData = $resulttoi->fetch_assoc()) {
                    $option = $optionData['p_name'];?>
                    <option value="<?php echo $option; ?>"><?php echo $option; ?> </option>
              <?php  }
              }
    ?>
                   
  </select>

  <input type="date"  name="date">
<input type="submit" name="selectdate" value="Search">
    </form>

  </div>
  <div id="">
  <canvas id="every" style="display: block; box-sizing: border-box; height: 500px; width: 900px;" class="chartjs-render-monitor" width="1144" height="570"></canvas>
</div>

<script>
  var xvalues=<?php echo(json_encode($jk)); ?>;
 var yvalues=<?php echo(json_encode($notjk)); ?>;
 console.log(xvalues);
var ctx = document.getElementById('every').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels:xvalues,
    datasets: [{
      label: 'Sales',
      data: yvalues,
      backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
    }]
  },
  options: {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
</script>
</div>

</body>
</html>

