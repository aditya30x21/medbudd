console.log("ADDED");

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        datasets: [{
            label: 'Sales',
            data: [38, 55, 30, 25, 58, 15],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
        }],
        labels: ['Paracetamol 500mg', 'Crocin Advance', 'Advog 0.3', 'Dolo 600mg', 'Tossex DMR']
    },
    options: {
        scales: {
            xAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});

/* Line Chart */
var ctx1 = document.getElementById('myChart1').getContext('2d');
var myChart = new Chart(ctx1, {
    type: 'line',
    data: {
        labels: ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
        datasets: [{
            label: 'Sales',
            data: [47540.60, 57540.60, 55540.60, 67540.60, 51540.60, 7540.60],
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
        }]
    },
    options: {
        responsive: true,
        plugins: {
            annotation: {
                annotations: [{
                    type: 'line',
                    mode: 'vertical',
                    scaleID: 'x',
                    value: 'Mar',
                    borderColor: 'black',
                    borderWidth: 1,
                    label: {
                        content: 'Spring Sale'
                    }
                }]
            }
        }
    }
});