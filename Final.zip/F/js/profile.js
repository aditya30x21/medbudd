// var cal = new CalHeatMap();
// cal.init({
// 	domain: "month",
// 	range: 12,
// 	cellSize: 14,
// 	cellPadding: 5,
// 	start: new Date(),
// });

// var data1 = anychart.data.set([
// 	['Completed', 74],
// 	['Remaining', 26],
// ]);

// var chart = anychart.pie(data1);
// chart.innerRadius('35%')
// var palette = anychart.palettes.distinctColors();
// palette.items([
// 	{ color: '#5db64f' },
// 	{ color: '#ff0055' },
// ]);
// chart.palette(palette);
// chart.tooltip().format('{%PercentValue}%');
// var label = anychart.standalones.label();
// label
// 	.useHtml(true)
// 	.text(
// 		'<span style = "color: #313136; font-size:20px;"></span>' +
// 		'<br/><br/></br><span style="color:#000000; font-size: 14px;"></span>'
// 	)
// 	.position('center')
// 	.anchor('center')
// 	.hAlign('center')
// 	.vAlign('middle');
// chart.center().content(label);
// chart.container('container');

// var chartType = document.getElementById('targetType');
// chartType.addEventListener("change", function () {
// 	document.getElementById('container').style.display = "block";
// 	chart.draw();
// });


/* Monthly Target Line Graph*/

var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
	type: 'bar',
	data: {
		labels: ['Jan', 'Feb', 'Mar','Apr', 'May', 'Jun','Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		datasets: [{
			label: 'Monthly Targets',
			data: [100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650],
			fill: false,
			borderColor: 'rgba(54, 162, 235, 1)',
			borderWidth: 1
		}, {
			label: 'Monthly Achieved',
			data: [80, 120, 190, 240, 290, 340, 380, 420, 480, 530, 570, 610],
			fill: false,
			borderColor: 'rgba(255, 99, 132, 1)',
			borderWidth: 1
		}]
	},
	options: {
		animation: {
			duration: 1000
		},
		responsive: true,
		maintainAspectRatio: false,
		scales: {
			yAxis: [{
				ticks: {
					beginAtZero: true
				}
			}]
		}
	}
});


