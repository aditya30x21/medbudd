console.log("HELLO");




/* Change color of Status */
var elements = document.getElementsByClassName("mrStatus");

for (var i = 0; i < elements.length; i++) {
  if (elements[i].textContent === "Available") {
    elements[i].style.color = "green";
  } else {
    elements[i].style.color = "red";
  }
}

/* Edit MR Option */
// var edit = document.getElementsByClassName("edit");
// edit.addEventListener("click", myFunction() {
//   document.getElementById("editOption").style.display = "block";
// });

const showButton = document.getElementById("edit");
var cnt = 0;

showButton.addEventListener("click", function() {
  if(cnt % 2===0){
    document.getElementById("editOption").style.display = "block";
  } else {
    document.getElementById("editOption").style.display = "none";
  }
  cnt++;
});
const showButton1 = document.getElementById("edit2");
var cnt = 0;

showButton1.addEventListener("click", function() {
  if(cnt % 2===0){
    document.getElementById("editOption2").style.display = "block";
  } else {
    document.getElementById("editOption2").style.display = "none";
  }
  cnt++;
});