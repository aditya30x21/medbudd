console.log('Added')

function checkFName() {
    var fname = document.getElementById('c_fname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    var name = fname.value;

    if (name !== "" && !regName.test(name)) {
        document.getElementById("toHide1").style.display = "block";
        fname.innerText = "";
        return false;
    } else {
        document.getElementById("toHide1").style.display = "none";
        return true;
    }
}
function checkLName() {
    var fname = document.getElementById('c_lname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    var name = fname.value;

    if (name !== "" && !regName.test(name)) {
        document.getElementById("toHide2").style.display = "block";
        fname.innerText = "";
        return false;
    } else {
        document.getElementById("toHide2").style.display = "none";
        return true;
    }
}
function checkEmail() {
    var fname = document.getElementById('c_email');
    var regName = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var name = fname.value;

    if (name !== "" && !regName.test(name)) {
        document.getElementById("toHide3").style.display = "block";
        fname.innerText = "";
        return false;
    } else {
        document.getElementById("toHide3").style.display = "none";
        return true;
    }
}
function checkCom() {
    var fname = document.getElementById('c_cname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    var name = fname.value;

    if (name !== "" && !regName.test(name)) {
        document.getElementById("toHide4").style.display = "block";
        fname.innerText = "";
        return false;
    } else {
        document.getElementById("toHide4").style.display = "none";
        return true;
    }
}
function checkDiv() {
    var fname = document.getElementById('c_dname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    var name = fname.value;

    if (name !== "" && !regName.test(name)) {
        document.getElementById("toHide5").style.display = "block";
        fname.innerText = "";
        return false;
    } else {
        document.getElementById("toHide5").style.display = "none";
        return true;
    }
}
function checkAadhar() {
    var fname = document.getElementById('c_aadhar');
    var regName = /^[0-9]+$/;
    var name = fname.value;

    if (name !== "" && !name.match(regName)) {
        document.getElementById("toHide6").style.display = "block";
        document.getElementById("toHide6").innerText = "Only Numbers Allowed"
        return false;
    } else if (name.length > 12) {
        document.getElementById("toHide6").style.display = "block";
        document.getElementById("toHide6").innerText = "Length should be 12"
        return false;
    } else {
        document.getElementById("toHide6").style.display = "none";
        return true;
    }
}
function matchPass(){
    var pass1 = document.getElementById('c-pass').value;
    var pass2 = document.getElementById('c-confPass').value;

    if (pass1 != pass2) {
        document.getElementById("toHide7").style.display = "block";
        return false;
    } else {
        document.getElementById("toHide7").style.display = "none";
        return true;
    }
}
function validateForm() {

    var fname = document.getElementById('c_fname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    if (fname != null) {
        var name = fname.value;
        if (name !== "" && !regName.test(name)) {
            document.getElementById("toHide1").style.display = "block";
            fname.innerText = "";
            return false;
        }
    }

    fname = document.getElementById('c_lname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    if (fname != null) {
        var name = fname.value;
        if (name !== "" && !regName.test(name)) {
            document.getElementById("toHide2").style.display = "block";
            fname.innerText = "";
            return false;
        }
    }

    fname = document.getElementById('c_email');
    var regName = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (fname != null) {
        var name = fname.value;
        if (name !== "" && !regName.test(name)) {
            document.getElementById("toHide3").style.display = "block";
            fname.innerText = "";
            return false;
        }
    }

    fname = document.getElementById('c_cname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    if (fname != null) {
        var name = fname.value;
        if (name !== "" && !regName.test(name)) {
            document.getElementById("toHide4").style.display = "block";
            return false;
        }
    }

    fname = document.getElementById('c_dname');
    var regName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/g;
    if (fname != null) {
        var name = fname.value;
        if (name !== "" && !regName.test(name)) {
            document.getElementById("toHide5").style.display = "block";
            fname.innerText = "";
            return false;
        }
    }

    fname = document.getElementById('c_aadhar');
    var regName = /^[0-9]+$/;
    if (fname != null) {
        var name = fname.value;
        if (name !== "" && !name.match(regName)) {
            document.getElementById("toHide6").style.display = "block";
            document.getElementById("toHide6").innerText = "Only Numbers Allowed"
            return false;
        } else if (name.length != 12) {
            document.getElementById("toHide6").style.display = "block";
            document.getElementById("toHide6").innerText = "Length should be 12"
            return false;
        }
    }

    var pass1 = document.getElementById('c-pass').value;
    var pass2 = document.getElementById('c-confPass').value;

    if (pass1 != pass2) {
        document.getElementById("toHide7").style.display = "block";
        return false;
    } 
}
function msgSent(){
    alert("Message Sent");
}
