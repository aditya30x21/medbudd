<?php

if (isset($_POST['button1'])) {
  
    button1();
}
$conn = mysqli_connect('localhost', 'root', '', 'medbudd');


//$productresult = mysqli_query($conn, $sql);
//$products = mysqli_fetch_all($productresult, MYSQLI_ASSOC);
//mysqli_free_result($productresult);
//mysqli_close($conn);
//print_r($products);



// ithe takkkkkkkkkkkkkkkkkkkkkkkkk

$pageId = 102;

require 'partials/_dbconnect.php';
function products($conn)
{
    echo "<h3>Products</h3>";
    $orders = "SELECT * FROM products";
    $result = mysqli_query($conn, $orders);
    
    if (mysqli_num_rows($result) > 0) {
        echo "<div class='thirdRow'>";

       $sql = "SELECT * FROM medical_reg";
        $resulttoi = $conn->query($sql);    
        ?>
    <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <!--<form method='post' action='" . $_SERVER['PHP_SELF']>   -->
        <select name="HQ">
                <option value="">Select HQ</option>
                <?php  
                    if($resulttoi->num_rows> 0){
                    while($optionData=$resulttoi->fetch_assoc()){
                    $option =$optionData['Medical Name'];
                        $id =$optionData['shopid'];
                ?>
                <option value="<?php echo $id; ?>" ><?php echo $option; ?> </option>
                <?php }}  ?>
         </select>
<br><br>
         <?php   
        echo "<table class='table'>";
        echo "<tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>MRP</th>
                <th>Quantity</th>
                <th>Select</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>" . $row["p_id"] . "</td><td>" . $row["p_name"] . "</td><td>" . $row["quantity"] . "</td> <td>" . $row["mrp"] . "</td><td><input type = 'checkbox' name='products[]' value='" . $row["p_name"] . "'></td></tr>";
        }
        echo "</table>";
        echo "<input type='submit' name='addProducts' value='Add'>";
        echo "</form>";
        echo "</div>";
    } else {
        echo "No results found";
    }
}


// $HQ = (isset($_POST['HQ']) ? $_POST['HQ']: null);
// print_r("HQ is: ". $_POST['HQ']);

if(isset($_POST['addProducts'])){
   $hq=$_POST['HQ'];
   $selectedProducts = $_POST['products'];
   if(!empty($selectedProducts)){
       $table = "assigned";
       $columns = "mr_id, p_name, achieved, target";
       $values = "";
       foreach($selectedProducts as $productName){
           $values .= "(" . mysqli_real_escape_string($conn, $pageId) . ", '" . mysqli_real_escape_string($conn, $productName) . "', 0, 0),";
       }
       $values = rtrim($values, ",");
       $insertQuery = "INSERT INTO ".$table." (".$columns.") VALUES ".$values;
       mysqli_query($conn, $insertQuery);

       // Store the mr_id in a session variable
       session_start();
       $_SESSION['mr_id'] = mysqli_insert_id($conn);

       header("Location: ".$_SERVER['PHP_SELF']."?mr_id=".$pageId);
       // header("Location: ".$_SERVER['PHP_SELF']."?page_id=".$pageId);
       exit;
   }
   
}



function assigned($conn)
{
    global $pageId;

    $orders = "SELECT mr_id, p_name, achieved, target FROM assigned WHERE mr_id = $pageId";
    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>MR ID</th>
                <th>Product Name</th>
                <th>Achieved</th>
                <th>Target</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr><td>" . $row["mr_id"] . "</a></td><td>" . $row["p_name"] . "</td> <td>" . $row["achieved"] . "</td><td>" . $row["target"] . "</td></tr>";
        }
        echo "</table>";
        echo "</div>";
 
    } else {
        echo "No results found";
    }

    
}



//--------------------


//--------------------
use Google\Cloud\Vision\VisionClient;


function button1() {
  
require "vendor/autoload.php";

    $vision = new VisionClient(['keyFile' => json_decode(file_get_contents("key.json"),true)]);
    $family=fopen("f.jpg",'r');
    $image = $vision->image($family,['TEXT_DETECTION']);
    $result=$vision->annotate($image)->text();
    $store=""; $i=0; $heading=array(array()); $avgdis=0; $count=0; $serial=[];
    $serialno=array(array()); $desc=""; $qty=""; $unit="";
    $description=[]; $unitt=[]; $quantity=[];
    $varchavg=0;
foreach($result as $text)
{    
    if($i==0)
    {
            $i++;
            continue;  

    }
    $store=$text->description();    
    $store = preg_replace('/\d+/u', '', $store);
    $store = preg_replace('/[^\p{L}\p{N}\s]/u', '', $store);
    $store = preg_replace("/\s+/", "", $store);
    $store = strtolower($store);

    if(str_contains($store,"srno") or str_contains($store,"sr")){
    $heading[0][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[0][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[0][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }
    else if(str_contains($store,"description")){
    $heading[1][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[1][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[1][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }
    else if(str_contains($store,"qty")){
    $heading[2][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[2][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[2][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }
    else if(str_contains($store,"unit")){
    $heading[3][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $heading[3][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $heading[3][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    }

}
$i=0;
foreach($result as $text)
{
    if($i==0)
    {
        $i++;
        continue;

    } 
    $verticex0 = (int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
    $verticex1 = (int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
    $verticex2 = (int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
    $verticex3 = (int)$text->info()["boundingPoly"]["vertices"]["3"]["x"];
   
    $avgdis=($heading[0][2]+$heading[0][0]+$heading[1][0])/3;
    $store=$text->description();    
    $store = preg_replace('/\d+/u', '', $store);
    $store = preg_replace('/[^\p{L}\p{N}\s]/u', '', $store);
    $store = preg_replace("/\s+/", "", $store);
    $store = strtolower($store);

    if($verticex0<$avgdis and is_numeric($text->description()))
    {
        $serial[$count]=$text->description();
        $serialno[$count][0]=(int)$text->info()["boundingPoly"]["vertices"]["0"]["y"];
        $serialno[$count][1]=(int)$text->info()["boundingPoly"]["vertices"]["1"]["y"];
        $serialno[$count][2]=(int)$text->info()["boundingPoly"]["vertices"]["2"]["y"];
        $count++;
    }
}

$i=0;

for($j=0;$j<$count-1;$j++)
{
    foreach($result as $text)
    {
        if($i==0)
        {
            $i++;
            continue;
    
        }
        $verticex0 = (int)$text->info()["boundingPoly"]["vertices"]["0"]["x"];
        $verticex1 = (int)$text->info()["boundingPoly"]["vertices"]["1"]["x"];
        $verticex2 = (int)$text->info()["boundingPoly"]["vertices"]["2"]["x"];
        $verticex3 = (int)$text->info()["boundingPoly"]["vertices"]["3"]["x"];     
        
        $verticey0 = (int)$text->info()["boundingPoly"]["vertices"]["0"]["y"];
        $verticey1 = (int)$text->info()["boundingPoly"]["vertices"]["1"]["y"];
        $verticey2 = (int)$text->info()["boundingPoly"]["vertices"]["2"]["y"];
        $verticey3 = (int)$text->info()["boundingPoly"]["vertices"]["3"]["y"];     

        if($verticey0<($serialno[$j+1][0]+$serialno[$j][0]+$serialno[$j][2])/3 and $verticey0>($serialno[$j][0]-($serialno[$j][0]/10)) )
        {   
           
            //$varchavg=(($serialno[$j+1][0]+$serialno[$j][0]+$serialno[$j][2])/3);
            $a=$serialno[$j+1][0];
            if($verticex0>=(($heading[0][0]+$heading[0][2]+$heading[1][0])/3) and $verticex0<$heading[2][0])
            {
                $desc=$desc." ".$text->description();
             

            }
            else if($verticex0>=(($heading[1][0]+$heading[1][2]+$heading[2][0])/3) and $verticex0<$heading[3][0])
            {
                $qty=$qty." ".$text->description();
            } 
            else if($verticex0>=(($heading[2][0]+$heading[2][2]+$heading[3][0])/3) and $verticex0<(($heading[3][2]+$heading[3][0])/2))
            {
                $unit=$unit.$text->description();
            }
        }
    }
    $description[$j]=$desc;
    $quantity[$j]=$qty;
    $unitt[$j]=$unit;
    $desc=null; $qty=""; $unit="";
}

echo "<table><tr><th>Description</th><th>Quantity</th><th>Unit</th></tr>";

for($j=0;$j<$count-1;$j++)
{
    
echo "<tr>
<td>{$description[$j]}</td>
<td>{$quantity[$j]}</td>
<td>{$unitt[$j]}</td>
</tr> ";
}
echo "</table>";
}
?>


<!-- ---------------------------------------------- -->
<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>


    <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="submit" name="button1" value="Scan" />


    </form>

    <div>

        <div class='products'>
            <?php echo products($conn); ?>
            
        </div>
        <br>
        <div class='products'>
            <?php echo assigned($conn); ?>
        </div>

        <br>

    </div>


</body>

</html>