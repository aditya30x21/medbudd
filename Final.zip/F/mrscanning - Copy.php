<?php require 'partials/_dbconnect.php' ?>
<?php
// $conn = mysqli_connect('localhost', 'root', '', 'medbud');
session_start();

$mr = $_SESSION['username'];
$sql = "SELECT mr_id FROM mr_app_info WHERE email = '$mr'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$pageId = $row['mr_id'];

function target($conn)
{
    global $pageId;

    $sql = "SELECT sum(unit_target) as ut FROM assigned WHERE mr_id = $pageId";
    $sql1 = "SELECT sum(quantity) as ua FROM orderstaken WHERE mr_id = $pageId";

    $result = mysqli_query($conn, $sql);
    $result1 = mysqli_query($conn, $sql1);

    if (mysqli_num_rows($result) > 0 && mysqli_num_rows($result1) > 0) {
        echo "<div class='secondRow'>";
        echo "<div class='box11 boxes'>";
        echo "<i class='fa fa-notes-medical sizeInc'></i>";
        echo "<h3 class='text-black'>Sales Achieved</h3>";

        if ($row = mysqli_fetch_assoc($result1)) {
            $products = $row['ua'] ?? 0; // Assign 0 if $row['ua'] is null or undefined
            echo "<h6 class='text-black'> $products </h6>";
        }

        echo "</div>";
        echo "<div class='box12 boxes'>";
        echo "<i class='fa fa-bullseye sizeInc'></i>";
        echo "<h3 class='text-black'>Sales Target</h3>";

        if ($row = mysqli_fetch_assoc($result)) {
            $products = $row['ut'] ?? 0; // Assign 0 if $row['ut'] is null or undefined
            echo "<h6 class='text-black'> $products </h6>";
        }

        echo "</div>";
        echo "</div>";

    } else {
        echo "No results found";
    }
}

function products($conn)
{
    // echo "<h3>Products</h3>";
    $orders = "SELECT * FROM products";
    $result = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result) > 0) {
        echo "<h3 class='text-black'>Products</h3>";
        echo "<div class='secondRow'>";

        $sql = "SELECT * FROM medical_registration";
        $resulttoi = $conn->query($sql);
        ?>
        <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <select name="HQ" class='form-select form-select-lg mb-3' aria-label='.form-select-lg example'>
                echo "<h3>Products</h3>";
                <option selected>Select Medical</option>
                <?php
                if ($resulttoi->num_rows > 0) {
                    while ($optionData = $resulttoi->fetch_assoc()) {
                        $option = $optionData['medical_name'];
                        $id = $optionData['shop_id'];
                        ?>
                        <option value="<?php echo $option; ?>"><?php echo $option; ?> </option>
                    <?php }
                } ?>
            </select>
            <br><br>
            <?php


            echo "<table class='table'>";
            echo "<tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>MRP</th>
                <th>Unit</th>
                <th>Select</th>
            </tr>";


            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>" . $row["p_id"] . "</td><td>" . $row["p_name"] . "</td><td>" . $row["mrp"] . "</td><td><input type='number' name='unit[" . $row["p_id"] . "]' size='3' min='1'></td><td><input type='checkbox' name='products[" . $row["p_id"] . "]' value='" . $row["p_name"] . "'></td></tr>";
            }

            echo "</table>";
            echo "<input type='submit' name='addProducts' value='Add' class='btn btn-primary btn-lg' > ";
            echo "</form>";
            echo "</div>";
    } else {
        echo "No results found";
    }
}

if (isset($_POST['addProducts'])) {
    $Shopname = $_POST['HQ'];
    $stmt = "select region from mr_data where mr_id='$pageId'";
    $result1 = mysqli_query($conn, $stmt);
    $row = mysqli_fetch_assoc($result1);
    $region = $row['region'];

    // print_r($result1);
    $selectedProducts = $_POST['products'];
    $selectedUnits = $_POST['unit'];
    if (!empty($selectedProducts) && !empty($selectedUnits)) {
        $table = "orderstaken";
        $columns = "p_name, mrp, quantity,shop_name, region, mr_id";
        $values = "";
        $mr_id = mysqli_real_escape_string($conn, $pageId);
        /*
        foreach ($selectedProducts as $productId => $productName) {
            $unit = mysqli_real_escape_string($conn, $selectedUnits[$productId]);
            $values .= "('" . $mr_id . "', '" . mysqli_real_escape_string($conn, $productName) . "', 0, '" . $unit . "'),";
        }
        */
        // foreach ($selectedProducts as $productId => $productName) {
        //     $unit = mysqli_real_escape_string($conn, $selectedUnits[$productId]);
        //     $values .= "('" . mysqli_real_escape_string($conn, $productName) . "', 0, '" . $unit . "', '" . $Shopname . "', '".$region."', '" . $pageId . "'),";
        // }

        foreach ($selectedProducts as $productId => $productName) {
            $unit = mysqli_real_escape_string($conn, $selectedUnits[$productId]);

            // Retrieve the MRP from the "products" table
            $mrpQuery = "SELECT mrp FROM products WHERE p_id = '" . $productId . "'";
            $mrpResult = mysqli_query($conn, $mrpQuery);
            $mrpRow = mysqli_fetch_assoc($mrpResult);
            $mrp = $mrpRow['mrp'];

            // Add the MRP to the INSERT query
            $values .= "('" . mysqli_real_escape_string($conn, $productName) . "', '" . $mrp . "', '" . $unit . "', '" . $Shopname . "', '" . $region . "', '" . $pageId . "'),";
        }

        if (!empty($values)) {
            $values = rtrim($values, ",");
            $insertQuery = "INSERT INTO " . $table . " (" . $columns . ") VALUES " . $values;
            mysqli_query($conn, $insertQuery);

            // Store the mr_id in a session variable
            session_start();
            $_SESSION['mr_id'] = mysqli_insert_id($conn);

            header("Location: " . $_SERVER['PHP_SELF'] . "?mr_id=" . $pageId);
            // header("Location: ".$_SERVER['PHP_SELF']."?page_id=".$pageId);
            exit;
        } else {
            echo "<script>alert('Please provide units greater than 0 for each selected product.');</script>";
        }
    } else {
        echo "<script>alert('Please select at least one product and provide units for each selected product.');</script>";
    }
}




function ordersTaken($conn)
{
    global $pageId;

    $orders = "SELECT p_name, mrp, quantity, region, shop_name FROM orderstaken WHERE mr_id = '$pageId' ";
    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow table-container'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>Product Name</th>
                <th>MRP</th>
                <th>Quantity</th>
                <th>Shop Name</th>
                <th>Region</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr><td>" . $row["p_name"] . "</a></td><td>" . $row["mrp"] . "</td> <td>" . $row["quantity"] . "</td><td>" . $row["shop_name"] . "</td><td>" . $row["region"] . "</td></tr>";
        }
        echo "</table>";
        echo "</div>";

    } else {
        echo "No results found";
    }
}

function assigned($conn)
{
    global $pageId;

    // $orders = "SELECT mr_id, p_name, SUM(unit_achieved) as total_achieved, SUM(unit_target) as total_target FROM assigned WHERE mr_id = $pageId GROUP BY p_name";

    $orders = "SELECT a.mr_id, a.p_name, COALESCE(b.total_units, 0) AS completed_units, COALESCE(a.total_units, 0) AS assigned_units 
    FROM (
      SELECT mr_id, p_name, SUM(unit_target) AS total_units
      FROM assigned
      WHERE mr_id = $pageId
      GROUP BY mr_id, p_name
    ) a
    LEFT JOIN (
      SELECT mr_id, p_name, SUM(quantity) AS total_units
      FROM orderstaken
      WHERE mr_id = $pageId
      GROUP BY mr_id, p_name
    ) b ON a.mr_id = b.mr_id AND a.p_name = b.p_name
    ";

    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow table-container'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>MR ID</th>
                <th>Product Name</th>
                <th>Achieved</th>
                <th>Target</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr>
                    <td>" . $row["mr_id"] . "</td>
                    <td>" . $row["p_name"] . "</td>
                    <td>" . $row["completed_units"] . "</td>
                    <td>" . $row["assigned_units"] . "</td>
                  </tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "No results found";
    }
}


function pharma($conn)
{

    $sql = "SELECT * FROM medical_reg";
    $resulttoi = $conn->query($sql);
    ?>
        <div class="forthRow">
            <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <h3 class="text-black">Pharmaceuticals</h3>
                <select name="HQQ" onchange="this.form.submit();">
                    echo "<h3>Products</h3>";
                    <option value="">Select HQ</option>
                    <?php
                    if ($resulttoi->num_rows > 0) {
                        while ($optionData = $resulttoi->fetch_assoc()) {
                            $option = $optionData['Medical Name'];
                            $id = $optionData['shopid'];
                            ?>
                            <option value="<?php echo $option; ?>"><?php echo $option; ?> </option>
                        <?php }
                    }
                    ?>
            </form>
        </div>
        <?php
}

if (isset($_POST['HQQ'])) {
    $a = $_POST['HQQ'];
    global $pageId;

    $orders = "SELECT p_name, mrp, quantity, region, shop_name FROM orderstaken WHERE mr_id = '$pageId' and shop_name = '$a'";
    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>Product Name</th>
                <th>MRP</th>
                <th>Quantity</th>
                <th>Shop Name</th>
                <th>Region</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr><td>" . $row["p_name"] . "</a></td><td>" . $row["mrp"] . "</td> <td>" . $row["quantity"] . "</td><td>" . $row["shop_name"] . "</td><td>" . $row["region"] . "</td></tr>";
        }
        echo "</table>";
        echo "</div>";

    } else {
        echo "No results found";
    }
}
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MeddBudd App</title>

        <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
        <link rel="stylesheet" href="fonts/icomoon/style.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/jquery-ui.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/owl.theme.default.min.css">
        <link rel="stylesheet" href="css/aos.css">
        <link rel="stylesheet" href="css/regManProfile.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="icon" href="Images/Logo.png" type="image/x-icon">
        <link rel="icon" href="Images/Logo.png" type="image/x-icon">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
            integrity="sha512-..." crossorigin="anonymous" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    </head>

    <body>

        <div class="site-wrap">
            <?php
            require 'navBar.php';
            ?>
            <div class="mainDashboard">
                <?php echo target($conn); ?>
                <div>
                    <h2></h2>
                    <?php echo products($conn); ?>
                </div>
                <div>
                    <br>
                    <button value="Scan"> <a href="camera.php">Scan</a></button>
                    <h3 class="text-black">OrdersTaken</h3>
                    <?php echo ordersTaken($conn); ?>
                </div>
                <div>
                    <h3 class="text-black">Assigned</h3>
                    <?php echo assigned($conn); ?>
                </div>


                <div>
                    <?php //echo pharma($conn); ?>
                </div>
            </div>
        </div>
    </body>

    </html>