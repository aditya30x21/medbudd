<html>
    <head>
    <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="site-navbar py-2">
            <div class="search-wrap">
                <div class="container">
                    <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
                    <form action="#" method="post">
                        <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
                    </form>
                </div>
            </div>

            <div class="container">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="logo">
                        <div class="site-logo">
                            <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo" class="logoimg">
                            MedBudd</a>
                        </div>
                    </div>
                <div class="main-nav d-none d-lg-block">
                    <nav class="site-navigation text-right text-md-center" role="navigation">
                        <ul class="site-menu js-clone-nav d-none d-lg-block">
                        <li class="active"><a href="index.php">Home</a></li>
                        <!-- <li><a href="shop.html">Store</a></li> -->
                        <!-- <li class="has-children">
                            <a href="#">Products</a>
                            <ul class="dropdown">
                                <li><a href="#">Supplements</a></li>
                                <li class="has-children">
                                    <a href="#">Vitamins</a>
                                    <ul class="dropdown">
                                        <li><a href="#">Supplements</a></li>
                                        <li><a href="#">Vitamins</a></li>
                                        <li><a href="#">Diet &amp; Nutrition</a></li>
                                        <li><a href="#">Tea &amp; Coffee</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Diet &amp; Nutrition</a></li>
                                <li><a href="#">Tea &amp; Coffee</a></li>

                            </ul>
                        </li> -->
                        <li><a href="about.html">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="icons">
                        <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span -->
                                <!-- class="icon-search"></span></a> -->
                        <!-- <a href="cart.html" class="icons-btn d-inline-block bag"> -->
                            <!-- <span class="icon-shopping-bag"></span> -->
                        <!-- </a> -->
                        <?php
                        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
                            echo
                                "<div class='dropdown'>
                                    <button class='dropbtn'><span class='icon-user'></span></button>
                                        <div class='dropdown-content'>
                                            <a href='logIn.php'>MR</a>
                                            <a href='adminLogin.php'>Admin</a>
                                        </div>
                                </div>
                                <a href='logIn.php' class='icons-btn d-inline-block bag'></a>
                                <a href='#' class='site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none'><span
                                class='icon-menu'></span></a>";
                        } else {
                            // Changes here
                            echo "<div class='dropdown'>
                            <button class='dropbtn'><span class='icon-user'></span></button>
                                <div class='dropdown-content'>
                                    <a href='profile.php'>MR</a>
                                </div>
                        </div>";
                            echo "<a href = 'mr_logout.php'>Logout</a>";
                        }

                        ?>
                    </div>
                <a href="logIn.php" class="icons-btn d-inline-block bag"></a>
                <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                    class="icon-menu"></span></a>
                </div>
            </div>
        </div>
    </body>
</html>