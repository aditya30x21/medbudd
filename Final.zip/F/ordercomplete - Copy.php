<?php require 'partials/_dbconnect.php' ?>
<?php

error_reporting(E_ERROR | E_PARSE);
session_start();

$mr = $_SESSION['username'];
$sql = "SELECT mr_id FROM mr_app_info WHERE email = '$mr'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$pageId = $row['mr_id'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Profile</title>

    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" type="text/css" href="css/regManProfile.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="Images/Logo.png" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"> </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>


    <div class="site-wrap">
        <?php
        require 'navBar.php';
        ?>
        <div class="mainDashboard">
            <?php

            function assigned($conn)
            {
                global $pageId;

                // $orders = "SELECT mr_id, p_name, SUM(unit_achieved) as total_achieved, SUM(unit_target) as total_target FROM assigned WHERE mr_id = $pageId GROUP BY p_name";
            
                $orders = "SELECT a.mr_id, a.p_name, COALESCE(b.total_units, 0) AS completed_units, COALESCE(a.total_units, 0) AS assigned_units 
    FROM (
      SELECT mr_id, p_name, SUM(unit_target) AS total_units
      FROM assigned
      WHERE mr_id = $pageId
      GROUP BY mr_id, p_name
    ) a
    LEFT JOIN (
      SELECT mr_id, p_name, SUM(quantity) AS total_units
      FROM orderstaken
      WHERE mr_id = $pageId
      GROUP BY mr_id, p_name
    ) b ON a.mr_id = b.mr_id AND a.p_name = b.p_name
    ";

                $result1 = mysqli_query($conn, $orders);

                if (mysqli_num_rows($result1) > 0) {
                    echo "<div class='thirdRow table-container'>";
                    echo "<table class='table'>";
                    echo "<tr>
                <th>MR ID</th>
                <th>Product Name</th>
                <th>Achieved</th>
                <th>Target</th>
            </tr>";

                    while ($row = mysqli_fetch_assoc($result1)) {
                        echo "<tr>
                    <td>" . $row["mr_id"] . "</td>
                    <td>" . $row["p_name"] . "</td>
                    <td>" . $row["completed_units"] . "</td>
                    <td>" . $row["assigned_units"] . "</td>
                  </tr>";
                    }
                    echo "</table>";
                    echo "</div>";
                } else {
                    echo "No results found";
                }
            }
            function shops($conn)
            {
                $sql = "SELECT * FROM medical_registration";
                $resulttoi = $conn->query($sql);
                ?>
                <div class="thirdRow table-container">
                    <form method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">

                        <select name="shops" class="form-select form-select mb-3" aria-label=".form-select-lg example">
                            <h3>Products</h3>
                            <option value="">Select Medical</option>
                            <?php
                            if ($resulttoi->num_rows > 0) {
                                while ($optionData = $resulttoi->fetch_assoc()) {
                                    $option = $optionData['medical_name'];
                                    $id = $optionData['shop_id'];
                                    ?>
                                    <option value="<?php echo $option; ?>"><?php echo $option; ?> </option>
                                <?php }
                            } ?>
                        </select>

                        <div class="md-form md-outline input-with-post-icon datepicker" id="customDays">
                            <input placeholder="Select date" type="date" id="Customization" class="form-control"
                                name="DATE">
                            <i class="fas fa-calendar input-prefix" tabindex=0></i>
                        </div>
                        <br>
                        <input type="submit" name="selectdate" value="GO" class="btn btn-primary btn-sm">
                        <input type="submit" name="completed" value="OK" class="btn btn-primary btn-sm">

                    </form>
                </div>
                <?php
            }

            // if(isset($_POST['selectdate'])) {
            
            //     // $new_date = date('Y-m-d', strtotime($_POST['bigD']));
            //     // echo $new_date;
            //     global $pageId;
            
            //     $orders = "SELECT p_name, mrp, quantity, region, shop_name FROM orderstaken WHERE mr_id = $pageId";
            //     $result1 = mysqli_query($conn, $orders);
            //     echo "<h3 class='text-black'>Orders Taken</h3>";
            //     if (mysqli_num_rows($result1) > 0) {
            //         echo "<div class='thirdRow'>";
            //         echo "<table class='table'>";
            //         echo "<tr>
            //                 <th>Product Name</th>
            //                 <th>MRP</th>
            //                 <th>Quantity</th>
            //                 <th>Shop Name</th>
            //                 <th>Region</th>
            //             </tr>";
            
            //         while ($row = mysqli_fetch_assoc($result1)) {
            //             echo "<tr><td>" . $row["p_name"] . "</a></td><td>" . $row["mrp"] . "</td> <td>" . $row["quantity"] . "</td><td>" . $row["shop_name"] . "</td><td>" . $row["region"] . "</td></tr>";
            //         }
            //         echo "</table>";
            //         echo "</div>";
            
            //     } else {
            //         echo "No results found";
            //     }
            // }
            

            if (isset($_POST['selectdate'])) {

                $new_date = date('Y-m-d', strtotime($_POST['DATE']));
                $shops = $_POST['shops'];
                global $pageId;

                $orders = "SELECT p_name, mrp, quantity, region, shop_name FROM orderstaken WHERE shop_name = '$shops' and date='$new_date' and mr_id='$pageId';";
                $result1 = mysqli_query($conn, $orders);
                echo "<h3 class='text-black'>Orders Taken</h3>";
                if (mysqli_num_rows($result1) > 0) {

                    echo "<div class='thirdRow'>";
                    echo "<form method='post' action='ordercomplete.php'>";
                    echo "<table class='table'>";
                    echo "<tr>
              <th>Product Name</th>
              <th>MRP</th>
              <th>Quantity</th>
              <th>Shop Name</th>
              <th>Region</th>
              <th>Add</th>
          </tr>";

                    while ($row = mysqli_fetch_assoc($result1)) {
                        echo "<tr>
                  <td>" . $row["p_name"] . "</td>
                  <td><input type='text' name='mrp[]'></td>
                  <td>" . $row["quantity"] . "</td>
                  <td>" . $row["shop_name"] . "</td>
                  <td>" . $row["region"] . "</td>
                  <td><input type='checkbox' name='select[]'></td>
              </tr>";
                    }

                    echo "</table>";


                    echo "<input type='hidden' name='pageId' value='$pageId'>"; // Add hidden input for pageId
                    echo "<input type='submit' name='submit' value='Add'>";
                    echo "</form>";
                    echo "</div>";

                } else {
                    echo "No results found";
                }
            }

            if (isset($_POST['submit'])) {
                if (isset($_POST['select'])) { // Check if 'select' key exists in $_POST array
                    // Iterate through the selected rows
                    foreach ($_POST['select'] as $index => $value) {
                        if ($value == 'on') {
                            $mrp = $_POST['mrp'][$index];

                            // Perform necessary validations on the input values
            
                            // Retrieve the mr_name based on the $pageId
                            $mrNameQuery = "SELECT CONCAT(first_name, ' ', last_name) AS mr_name FROM mr_app_info WHERE mr_id = $pageId";
                            $mrNameResult = mysqli_query($conn, $mrNameQuery);

                            if ($mrNameResult && mysqli_num_rows($mrNameResult) > 0) {
                                $mrNameRow = mysqli_fetch_assoc($mrNameResult);
                                $mrName = $mrNameRow['mr_name'];
                            } else {
                                // Handle the case when no MR name is found for the given MR app ID
                                $mrName = "Unknown";
                            }

                            // Prepare the INSERT statement
                            $insertQuery = "INSERT INTO orderscomplete (mr_id, pname, totalprice, unit, shopname, region, date, mrname)
                                            SELECT $pageId, p_name, 0, '$mrp', shop_name, region, CURDATE(), '$mrName'
                                            FROM orderstaken
                                            WHERE mr_id = $pageId
                                            LIMIT 1";

                            // Execute the INSERT statement
                            mysqli_query($conn, $insertQuery);
                            $new_date = date('Y-m-d', strtotime($_POST['DATE']));
                            $shops = $_POST['shops'];
                            global $pageId;

                            $orders = "DELETE  FROM orderstaken WHERE shop_name = '$shops' and date='$new_date' and mr_id='$pageId';";
                            if ($conn->query($orders) === TRUE) {
                                echo "Record deleted successfully";
                            } else {
                                echo "Error deleting record: " . $conn->error;
                            }


                        }
                    }
                }

                // Redirect to a success page or display a success message
                // ...
            }





            ?>
            <div>
                <?php echo shops($conn); ?>
            </div>
            <h3>Assigned</h3>

            <?php echo assigned($conn); ?>
            <button value="scan" class="btn btn-primary btn-light"><a href="assign.php">Scan</a></button>
            <!-- <button value="scan" class="btn btn-primary btn-lg"><a href="assign.php">Scan</a></button> -->
        </div>
        <script>
            var xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
            var yValues = [55, 49, 44, 24, 15];
            var barColors = ["red", "green", "blue", "orange", "brown"];

            new Chart("myChart", {
                type: "bar",
                data: {
                    labels: xValues,
                    datasets: [{
                        backgroundColor: barColors,
                        data: yValues
                    }]
                },
                options: { ...}
            });
        </script>

</body>

</html>