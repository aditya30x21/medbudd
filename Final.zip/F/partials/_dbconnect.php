<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "medbudd";

$conn = mysqli_connect($server, $username, $password, $database);

if(!$conn){
//     echo "Successfully Connected";
// }
// else{
    die("Error". mqsqli_connect_error());
}
?>