<?php require 'partials/_dbconnect.php' ?>
<?php


session_start();

$mr = $_SESSION['username'];
$sql = "SELECT mr_id FROM mr_app_info WHERE email = '$mr'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$pageId = $row['mr_id'];

// -------------------------------------

// echo "<h3>You are currently viewing record for MR with Id =  $pageId</h3>";
function mrInfo($conn)
{
    global $pageId;
    $sql = "SELECT * from mr_app_info where mr_id = $pageId";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $mr_name = $row["first_name"] . " " . $row["last_name"];
        $email = $row['email'];
        $region = $row['region'] .", ". $row['state'];
        $headquarters = $row["headquarter"].", ". $row['state'];
    } else {
        $mr_name = "No results found.";
        $email = "";
        $region = "";
        $headquarters = "";
    }
    return array("name" => $mr_name, "email" => $email, "region" => $region, "headquarters" => $headquarters);
}


function mrDetails($conn){
    global $pageId;
    $sql = "SELECT mr_name, region FROM mr_data WHERE mr_id = $pageId";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $mr_name = $row["mr_name"];
        $region = $row["region"];
    } else {
        $admin_name = "No results found.";
        $headquarters = "";
    }
    return array("name" => $mr_name, "region" => $region);

}

function target($conn)
{
    global $pageId;
    $sql = "SELECT unit_achieved, unit_target, achieved, target FROM mr_data WHERE mr_id = $pageId";
    $result = mysqli_query($conn, $sql);

    $sql2 = "SELECT sum(unit_target) FROM `assigned` as o_target WHERE mr_id = $pageId";
    $result2 = mysqli_query($conn, $sql2);

    $sql3 = "SELECT sum(quantity) FROM `orderstaken` as o_achieved WHERE mr_id = $pageId";
    $result3 = mysqli_query($conn, $sql3);


    if (mysqli_num_rows($result) > 0) {
        echo "<div class='thirdRow table-container'>";
        echo "<table class='table'>";
        echo "<tr>
                <th><b>Unit Achieved</b></th>
                <th>Unit Assigned</th>
                <th>Target Achieved</th>
                <th>Target Assigned</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>" . $row["unit_achieved"] . "</td><td>" . $row["unit_target"] . "</td><td>" . $row["achieved"] . "</td><td>" . $row["target"] . "</td></tr>";

        }
        echo "</table>";
        echo "</div>";

    } else {
        echo "No results found";
    }
}

function ordersTaken($conn)
{
    global $pageId;

    $orders = "SELECT p_name, mrp, quantity, region, shop_name FROM orderstaken WHERE mr_id = $pageId";
    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow table-container'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>Product Name</th>
                <th>MRP</th>
                <th>Quantity</th>
                <th>Shop Name</th>
                <th>Region</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr><td>" . $row["p_name"] . "</a></td><td>" . $row["mrp"] . "</td> <td>" . $row["quantity"] . "</td><td>" . $row["shop_name"] . "</td><td>" . $row["region"] . "</td></tr>";
        }
        echo "</table>";
        echo "</div>";

    } else {
        echo "No results found";
    }
}

function products($conn)
{
    echo "<h3>Products</h3>";
    $orders = "SELECT * FROM products";
    $result = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result) > 0) {
        echo "<div class='thirdRow table-container'>";
        echo "<form method='post' action='".$_SERVER['PHP_SELF']."'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>MRP</th>
            </tr>";
            /*
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>" . $row["p_id"] . "</td><td>" . $row["p_name"] . "</td><td>" . $row["mrp"] . "</td><td>" . $row["quantity"] . "</td><td><input type='text' name='unit[" . $row["p_id"] . "]' size='3'></td><td><input type='checkbox' name='products[" . $row["p_id"] . "]' value='" . $row["p_name"] . "'></td></tr>";
            }
            */
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>" . $row["p_id"] . "</td><td>" . $row["p_name"] . "</td><td>" . $row["mrp"] . "</td></tr>";
            }
            
        echo "</table>";
        // echo "<input type='submit' name='addProducts' class='pBtn' value='Add'>";
        echo "</form>";
        echo "</div>";
    } else {
        echo "No results found";
    }
}

/*
// No Need
if(isset($_POST['addProducts'])){
    $selectedProducts = $_POST['products'];
    $selectedUnits = $_POST['unit'];
    if(!empty($selectedProducts) && !empty($selectedUnits)){
        $table = "assigned";
        $columns = "mr_id, p_name, unit_achieved, unit_target";
        $values = "";
        $mr_id = mysqli_real_escape_string($conn, $pageId);
        foreach($selectedProducts as $productId => $productName){
            $unit = mysqli_real_escape_string($conn, $selectedUnits[$productId]);
            $values .= "('" . $mr_id . "', '" . mysqli_real_escape_string($conn, $productName) . "', 0, '" . $unit . "'),";
        }
        
        if(!empty($values)){
            $values = rtrim($values, ",");
            $insertQuery = "INSERT INTO ".$table." (".$columns.") VALUES ".$values;
            mysqli_query($conn, $insertQuery);

            // Store the mr_id in a session variable
            session_start();
            $_SESSION['mr_id'] = mysqli_insert_id($conn);

            header("Location: ".$_SERVER['PHP_SELF']."?mr_id=".$pageId);
            // header("Location: ".$_SERVER['PHP_SELF']."?page_id=".$pageId);
            exit;
        } else {
            echo "<script>alert('Please provide units greater than 0 for each selected product.');</script>";
        }
    } else {
        echo "<script>alert('Please select at least one product and provide units for each selected product.');</script>";
    }
}
*/


function assigned($conn){
    global $pageId;

    // $orders = "SELECT mr_id, p_name, SUM(unit_achieved) as total_achieved, SUM(unit_target) as total_target FROM assigned WHERE mr_id = $pageId GROUP BY p_name";

    $orders = "SELECT a.mr_id, a.p_name, COALESCE(b.total_units, 0) AS completed_units, COALESCE(a.total_units, 0) AS assigned_units 
    FROM (
      SELECT mr_id, p_name, SUM(unit_target) AS total_units
      FROM assigned
      WHERE mr_id = $pageId
      GROUP BY mr_id, p_name
    ) a
    LEFT JOIN (
      SELECT mr_id, p_name, SUM(quantity) AS total_units
      FROM orderstaken
      WHERE mr_id = $pageId
      GROUP BY mr_id, p_name
    ) b ON a.mr_id = b.mr_id AND a.p_name = b.p_name
    ";

    $result1 = mysqli_query($conn, $orders);

    if (mysqli_num_rows($result1) > 0) {
        echo "<div class='thirdRow table-container'>";
        echo "<table class='table'>";
        echo "<tr>
                <th>MR ID</th>
                <th>Product Name</th>
                <th>Achieved</th>
                <th>Target</th>
            </tr>";

        while ($row = mysqli_fetch_assoc($result1)) {
            echo "<tr>
                    <td>" . $row["mr_id"] . "</td>
                    <td>" . $row["p_name"] . "</td>
                    <td>" . $row["completed_units"] . "</td>
                    <td>" . $row["assigned_units"] . "</td>
                  </tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "No results found";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MR Profile</title>

    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/regManProfile.css?v=2">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="Images/Logo.png" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bar Graph -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-..." crossorigin="anonymous" />
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>

<body>
    <div class="site_wrap">
        <div class="site-navbar py-2">
            <div class="search-wrap">
                <div class="container">
                    <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
                    <form action="#" method="post">
                        <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
                    </form>
                </div>
            </div>

            <div class="container">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="logo">
                        <div class="site-logo">
                            <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo"
                                    class="logoimg">
                                MedBudd</a>
                        </div>
                    </div>
                    <div class="main-nav d-none d-lg-block">
                        <nav class="site-navigation text-right text-md-center" role="navigation">
                            <ul class="site-menu js-clone-nav d-none d-lg-block">
                                <li class="active"><a href="index.php">Home</a></li>
                                <!-- <li><a href="shop.php">Store</a></li> -->
                                <li><a href="about.php">About</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="icons">
                        <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span -->
                                <!-- class="icon-search"></span></a> -->
                        <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
                            <!-- <span class="icon-shopping-bag"></span> -->
                        <!-- </a> -->
                        <?php
                        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
                            echo
                                "<div class='dropdown'>
                                    <button class='dropbtn'><span class='icon-user'></span></button>
                                        <div class='dropdown-content'>
                                            <a href='logIn.php'>MR</a>
                                            <a href='adminLogin.php'>Admin</a>
                                        </div>
                                </div>
                                <a href='logIn.php' class='icons-btn d-inline-block bag'></a>
                                <a href='#' class='site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none'><span
                                class='icon-menu'></span></a>";
                        } else {
                            // Changes here
                            // echo "<a href = 'regManagerProfile.php'><button class='dropbtn'><span class='icon-user'></span></button></a>";
                            echo "<a href = 'mr_logout.php'>Logout</a>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-light py-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-0"><a href="index.php">Home</a> <span class="mx-2 mb-0">/</span> <strong
                            class="text-black">MR Stats</strong></div>
                </div>
            </div>
        </div>
        <div class="mainDashboard">
            <div class="firstRow">
                <div class="magProfile">
                    <div class="avatar">
                        <img src="./Images/person_1.png" alt="Avatar">
                    </div>
                    <div class="magDetails">
                    <?php
                      $mr = mrInfo($conn);
                      $name = $mr['name'];
                      $email = $mr['email'];
                      $region = $mr['region'];
                      $hq = $mr['headquarters'];

                      echo "<Label class='pdTxt text-black'>$name</Label>";
                      echo "<br>";
                      echo "<label class='pdTxt meEmail text-black'>$email</label>";
                      echo "<br>";
                      echo "<Label class='pdTxt text-black'>Region: $region</Label>";
                      echo "<br>";
                      echo "<Label class='pdTxt text-black'>Headquarter: $hq</Label>";
                      echo "<br>";
                    ?>
                    </div>
                </div>
            </div>

            <div>
              <div class="button-container">
                  <button class="pBtn"><a href="mrscanning.php">Scan</a></button>
                  <button class="pBtn"><a href="ordercomplete.php">Orders</a></button>
                  <button class="pBtn"><a href="addMediShop.php">Add Medical</a></button>
              </div>
              <div>

              </div>
            </div>

            <div class="thirdRow">
                <div class='products'>
                    <?php
                        echo products($conn);
                    ?>
                </div>
            </div>
            
            <div class='ordertaken'>
                <?php
                    echo '<h3>Orders Taken</h3>'; 
                    echo ordersTaken($conn);
                ?>
            </div>
            <br>
            <div class='assigned'>
                <?php
                    echo '<h3>Assigned</h3>'; 
                    echo assigned($conn);
                ?>
            </div>
            <br>
        </div>
    </div>
    <footer class="site-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

                        <div class="block-7">
                            <h3 class="footer-heading mb-4">About Us</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius quae reiciendis distinctio
                                voluptates
                                sed dolorum excepturi iure eaque, aut unde.</p>
                        </div>

                    </div>
                    <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
                        <h3 class="footer-heading mb-4">Quick Links</h3>
                        <ul class="list-unstyled">
                            <li><a href="#">Supplements</a></li>
                            <li><a href="#">Vitamins</a></li>
                            <li><a href="#">Diet &amp; Nutrition</a></li>
                            <li><a href="#">Tea &amp; Coffee</a></li>
                        </ul>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <div class="block-5 mb-5">
                            <h3 class="footer-heading mb-4">Contact Info</h3>
                            <ul class="list-unstyled">
                                <li class="address">Bhujbal Knowledge City, Adgaon, Nashik, Maharashtra, India</li>
                                <li class="phone"><a href="tel://919511660897">+91 9511660897</a></li>
                                <li class="email"><a
                                        href="email://rahulbyadav2002@gmail.com">rahulbyadav2002@gmail.com</a></li>
                            </ul>
                        </div>


                    </div>
                </div>
                <div class="row pt-5 mt-5 text-center">
                    <div class="col-md-12">
                        <p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script> All rights reserved | MedBudd
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>

                </div>
            </div>
        </footer>
</body>

</html>