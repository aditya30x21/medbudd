<?php
$showAlert = false;
$showError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  include 'partials/_dbconnect.php';

  $c_fname = $_POST["c_fname"];
  $c_lname = $_POST["c_lname"];
  $c_email = $_POST["c_email"];
  $state = $_POST["state"];
  $hq = $_POST["hq"];
  $pan_no = $_POST["pan"];
  $region = $_POST['region'];
  $aadhar = $_POST['c_aadhar'];
  $id = $_POST['c_id'];
  $password = $_POST["pass"];
  $cpassword = $_POST["c_pass"];

  // Check whether this username exists.
  $existSql = "SELECT * FROM `mr_app_info` WHERE email = '$c_email'";
  $result = mysqli_query($conn, $existSql);
  $numExistRows = mysqli_num_rows($result);
  if ($numExistRows > 0) {
    // exists = true;
    $showError = "Account for this Email ID already Exist";
  } else {
    // $exists = false;
    if (($password == $cpassword)) {
      $hash_password = password_hash($password, PASSWORD_DEFAULT);
      $sql = "INSERT INTO `mr_app_info` (`first_name`, `last_name`, `email`, `state`, `headquarter`, `pan_no`, `region`, `aadhar_number`, `id` , `password` ,`date`) VALUES ('$c_fname', '$c_lname', '$c_email', '$state', '$hq', '$pan_no', '$region', '$aadhar',  '$id', '$hash_password', current_timestamp())";
      $result = mysqli_query($conn, $sql);


      // $mr_data = "INSERT INTO `mr_data` (`m_id`, `mr_name`, `region`, `status`) VALUES (1, '$c_fname','$region', 'Available')";
      // $result_data = mysqli_query($conn, $mr_data);

      if ($result) {
        $showAlert = true;
        addMrData($conn, $c_fname, $region, $aadhar);
      }
    } else {
      $showError = "Password do not match";
    }
  }
}

function addMrData($conn, $c_fname, $region, $aadhar)
{

  $query = "SELECT `mr_id` FROM mr_app_info WHERE `aadhar_number` = $aadhar";
  $result = mysqli_query($conn, $query);

  if ($result) {
    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $mr_id = $row['mr_id'];
    } else {
      echo "No mr_id found for the given Aadhar number.";
    }
  } else {
    echo "Query failed: " . mysqli_error($conn);
  }

  $mr_data = "INSERT INTO `mr_data` (`mr_id`, `m_id`, `mr_name`, `region`, `status`) VALUES ($mr_id, 1, '$c_fname','$region', 'Available')";
  $result_data = mysqli_query($conn, $mr_data);
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MedBudd App</title>

  <link rel="stylesheet" href="css/login.css">
  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/signUp.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="Images/Logo.png" type="image/x-icon">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>

<body>
  <div class="site-wrap">
    <div class="site-navbar py-2">

      <div class="search-wrap">
        <div class="container">
          <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
          <form action="#" method="post">
            <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
          </form>
        </div>
      </div>

      <div class="container">
        <div class="d-flex align-items-center justify-content-between">
          <div class="logo">
            <div class="site-logo">
              <a href="index.php" class="js-logo-clone"><img src="./Images/Logo.png" alt="Logo" class="logoimg">
                MedBudd</a>
            </div>
          </div>
          <div class="main-nav d-none d-lg-block">
            <nav class="site-navigation text-right text-md-center" role="navigation">
              <ul class="site-menu js-clone-nav d-none d-lg-block">
                <li class="active"><a href="index.php">Home</a></li>
                <!-- <li><a href="shop.php">Store</a></li> -->
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
              </ul>
            </nav>
          </div>
          <div class="icons">
            <!-- <a href="#" class="icons-btn d-inline-block js-search-open"><span class="icon-search"></span></a> -->
            <!-- <a href="cart.php" class="icons-btn d-inline-block bag"> -->
            <!-- <span class="icon-shopping-bag"></span> -->
            <!-- <span class="number">2</span> -->
            <!-- </a> -->
            <div class="dropdown">
              <button class="dropbtn"><span class="icon-user"></span></button>
              <div class="dropdown-content">
                <a href="logIn.php">MR</a>
                <a href="adminLogin.php">Admin</a>
              </div>
            </div>
            <a href="logIn.php" class="icons-btn d-inline-block bag"></a>
            <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                class="icon-menu"></span></a>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section frm">
      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <form action="signUp.php" method="post">

              <div class="p-3 p-lg-5 border bg-white">

                <div class="form-group row">
                  <div class="col-md-6">
                    <label for="c_fname" class="text-black">First Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="c_fname" name="c_fname" onKeyUp="checkFName()" required>
                  </div>
                  <div class="col-md-6">
                    <label for="c_lname" class="text-black">Last Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control inpLname" id="c_lname" onKeyUp="checkLName()" name="c_lname"
                      required>
                  </div>
                  <div class="col-md-6">
                    <label for="c_fname" class="text-danger toHide" id="toHide1">Only Characters Allowed</label>
                  </div>
                  <div class="col-md-6">
                    <label for="c_lname" class="text-danger toHide" id="toHide2">Only Characters Allowed</label>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-12">
                    <label for="c_email" class="text-black">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="c_email" name="c_email" onKeyUp="checkEmail()"
                      placeholder="" required>
                  </div>
                  <div class="col-md-12">
                    <label for="c_email" class="text-danger toHide" id="toHide3">Enter Valid Email <span
                        class="text-danger">*</span></label>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-6">
                    <label for="state" class="text-black">State</label>
                    <span class="text-danger">*</span>
                    <select class="form-control" id="inputState" name="state" required>
                      <option value="SelectState">Select State</option>
                      <option value="Andra Pradesh">Andra Pradesh</option>
                      <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                      <option value="Assam">Assam</option>
                      <option value="Bihar">Bihar</option>
                      <option value="Chhattisgarh">Chhattisgarh</option>
                      <option value="Goa">Goa</option>
                      <option value="Gujarat">Gujarat</option>
                      <option value="Haryana">Haryana</option>
                      <option value="Himachal Pradesh">Himachal Pradesh</option>
                      <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                      <option value="Jharkhand">Jharkhand</option>
                      <option value="Karnataka">Karnataka</option>
                      <option value="Kerala">Kerala</option>
                      <option value="Madya Pradesh">Madya Pradesh</option>
                      <option value="Maharashtra">Maharashtra</option>
                      <option value="Manipur">Manipur</option>
                      <option value="Meghalaya">Meghalaya</option>
                      <option value="Mizoram">Mizoram</option>
                      <option value="Nagaland">Nagaland</option>
                      <option value="Orissa">Orissa</option>
                      <option value="Punjab">Punjab</option>
                      <option value="Rajasthan">Rajasthan</option>
                      <option value="Sikkim">Sikkim</option>
                      <option value="Tamil Nadu">Tamil Nadu</option>
                      <option value="Telangana">Telangana</option>
                      <option value="Tripura">Tripura</option>
                      <option value="Uttaranchal">Uttaranchal</option>
                      <option value="Uttar Pradesh">Uttar Pradesh</option>
                      <option value="West Bengal">West Bengal</option>
                      <option disabled style="background-color:#aaa; color:#fff">UNION Territories
                      </option>
                      <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands
                      </option>
                      <option value="Chandigarh">Chandigarh</option>
                      <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                      <option value="Daman and Diu">Daman and Diu</option>
                      <option value="Delhi">Delhi</option>
                      <option value="Lakshadeep">Lakshadeep</option>
                      <option value="Pondicherry">Pondicherry</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="hq" class="text-black">Headquarter</label>
                    <span class="text-danger">*</span>
                    <input type="text" class="form-control" id="c_cname" name="hq" onKeyUp="checkCom()" required>

                    <!-- <select class="form-control" id="inputDistrict" required> -->
                    <!-- <option value="">-- select one -- </option> -->
                    <!-- </select> -->
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-6">
                    <label for="pan" class="text-black">PAN Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="c_cname" name="pan" onKeyUp="checkCom()" required>
                  </div>
                  <div class="col-md-6">
                    <label for="region" class="text-black">Region <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="c_dname" name="region" onKeyUp="checkDiv()" required>
                  </div>
                  <div class="col-md-6">
                    <label for="pan" class="text-danger toHide" id="toHide4">Only Characters Allowed</label>
                  </div>
                  <div class="col-md-6">
                    <label for="region" class="text-danger toHide" id="toHide5">Only Characters Allowed</label>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-md-6">
                    <label for="c_aadhar" class="text-black">Aadhar Number<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="c_aadhar" name="c_aadhar" onkeyup="checkAadhar()"
                      required>
                  </div>
                  <div class="col-md-6">
                    <label for="c_id" class="text-black">Upload ID<span class="text-danger">*</span></label>
                    <input type="file" class="form-control" id="c_lname" name="c_id" required>
                  </div>
                  <div class="col-md-6">
                    <label for="c_id" class="text-danger toHide" id="toHide6">Only Numbers Allowed</label>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-6">
                    <label for="pass" class="text-black">Password<span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="c-pass" name="pass" required>
                  </div>
                  <div class="col-md-6">
                    <label for="c_pass" class="text-black">Confirm Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="c-confass" name="c_pass" required>
                  </div>
                  <div class="col-md-6">
                    <label for="c_fname" class="text-danger toHide" id="toHide7">Password not Matched</label>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-lg-12">
                    <input type="submit" class="btn btn-primary btn-lg btn-block" value="Submit"
                      onclick="validateForm()">
                  </div>
                </div>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>

  <div class="script">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script src="js/signUp.js"></script>
    <script src="js/validation.js"></script>
  </div>
</body>

</html>